import type { SiteData } from "./types";

const IMG = {
  kitchenHero: "/images/kitchen-hero.jpg",
  kitchenBlack: "/images/kitchen-black.jpg",
  kitchenGold: "/images/hero.jpg",
  kitchenCream: "/images/kitchen-1.jpg",
  kitchenWhite: "/images/kitchen-2.jpg",
  kitchenMarble:
    "https://images.pexels.com/photos/16501286/pexels-photo-16501286.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  kitchenWood:
    "https://images.pexels.com/photos/35021550/pexels-photo-35021550.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  dressingWood: "/images/dressing-1.jpg",
  dressingBeige: "/images/dressing-2.jpg",
  dressingLed:
    "https://images.pexels.com/photos/6587839/pexels-photo-6587839.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  dressingLoft:
    "https://images.pexels.com/photos/15522918/pexels-photo-15522918.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  dressingVanity:
    "https://images.pexels.com/photos/6198662/pexels-photo-6198662.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  officeHome: "/images/bureau-1.jpg",
  officeExec: "/images/bureau-2.jpg",
  officeLux:
    "https://images.pexels.com/photos/5502224/pexels-photo-5502224.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  officeModern:
    "https://images.pexels.com/photos/6899396/pexels-photo-6899396.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  workshop: "/images/about.jpg",
};

export const PLANNING_POINTS = [
  "معاينة مجانية للموقع ورفع المقاسات بدقة",
  "مخطط 2D يوضح توزيع الخزائن، الأدراج والأجهزة",
  "تصور 3D واقعي للخامات، الألوان والإضاءة",
  "تعديلات غير محدودة قبل الموافقة على التصنيع",
];

export const DEFAULT_DATA: SiteData = {
  version: 1,
  settings: {
    companyName: "Source Meuble",
    tagline: "نجارة فاخرة وتفصيل حسب الطلب",
    phone: "0550808843",
    whatsapp: "0550808843",
    mapUrl: "https://maps.app.goo.gl/SmXT1y4o9eNJnhxs6",
    address: "الجزائر — زيارة الورشة بموعد مسبق",
    email: "contact@sourcmeuble.dz",
    instagram: "https://www.instagram.com/",
    facebook: "https://www.facebook.com/",

    heroBadge: "تصميم 2D و 3D قبل التنفيذ",
    heroTitle: "مطابخ، دريسينغ ومكاتب",
    heroHighlight: "تُصنع على مقاسك",
    heroSubtitle:
      "Source Meuble ورشة نجارة متخصصة في الأثاث الفاخر حسب الطلب. نبدأ بمخطط 2D دقيق، ثم تصور 3D واقعي، ثم نصنّع ونركّب قطعتك بخامات أوروبية ويد حرفيين مهرة.",
    heroImage: IMG.kitchenHero,

    planningTitle: "خدمة التخطيط والتصور 2D و 3D",
    planningSubtitle:
      "قبل أن تلمس الخشب، نجعلك ترى بيتك. نرسم مخططاً ثنائي الأبعاد لمطبخك أو دريسينغك، ثم نحوّله إلى تصور ثلاثي الأبعاد واقعي بالخامات والألوان والإضاءة، لتقرر بثقة وبدون مفاجآت.",
    planningPoints: PLANNING_POINTS,

    aboutTitle: "من الورشة إلى بيتك، بلا وسطاء",
    aboutText:
      "نحن لا نبيع أثاثاً جاهزاً. في Source Meuble نصنع كل قطعة خصيصاً لك: نبدأ بالاستماع لحاجتك، نرفع المقاسات على عين المكان، ونرسم المخططات، ثم نصنّع في ورشتنا ونركّب قطعة واحدة فريدة تناسب مساحتك تماماً. نختار الخامات بعناية — ألواح مقاومة للرطوبة، مفصلات وأدراج هيدروليكية، وإضاءة LED مخفية — لأن التفاصيل الصغيرة هي الفرق بين أثاث وأثاث فاخر.",
    aboutImage: IMG.workshop,

    yearsExperience: 12,
    projectsCount: 320,
    clientsCount: 280,
  },
  categories: [
    {
      id: "kitchens",
      name: "المطابخ العصرية",
      englishName: "Custom Kitchens",
      tagline: "بدون مقابض، جزيرة واسعة، وخشب طبيعي",
      description:
        "مطابخ بتصاميم مينيمال وفاخرة: واجهات بدون مقابض، جزر مركزية، أجهزة مدمجة وإضاءة LED تحت الخزائن.",
      image: IMG.kitchenBlack,
    },
    {
      id: "dressing",
      name: "غرف الدريسنج",
      englishName: "Dressing Rooms",
      tagline: "أبواب زجاجية، إضاءة دافئة، وتنظيم ذكي",
      description:
        "دريسنج روم وخزائن جرارة بأبواب زجاج مدخن، أرفف مضاءة، أدراج مبطنة ووحدات تسريحة مدمجة.",
      image: IMG.dressingWood,
    },
    {
      id: "offices",
      name: "المكاتب والأثاث المكتبي",
      englishName: "Offices & Workspaces",
      tagline: "مكاتب تنفيذية، رفوف جدارية وحلول مريحة",
      description:
        "مكاتب تنفيذية ومنزلية برفوف مضاءة، خزائن مدمجة وحلول تخزين عملية تناسب العمل والدراسة.",
      image: IMG.officeExec,
    },
  ],
  products: [
    {
      id: "k-minimal-black",
      title: "مطبخ مينيمال أسود وخشب الجوز",
      categoryId: "kitchens",
      price: 420000,
      priceOnRequest: false,
      image: IMG.kitchenBlack,
      gallery: [IMG.kitchenBlack, IMG.kitchenMarble],
      description:
        "مطبخ بواجهات بدون مقابض يجمع بين الأسود المطفي وخشب الجوز الدافئ، مع جزيرة مركزية، فرن مدمج وخزانة نبيذ. تصميم يناسب المساحات المفتوحة ويُصنع بمقاس غرفتك بالكامل.",
      features: [
        "واجهات Handleless بدون مقابض",
        "خشب جوز طبيعي وألواح مقاومة للرطوبة",
        "جزيرة مركزية مع خزانة نبيذ مبردة",
        "إضاءة LED مخفية تحت الخزائن",
      ],
      featured: true,
      createdAt: "2025-11-02T10:00:00.000Z",
    },
    {
      id: "k-island-oak",
      title: "مطبخ عصري بجزيرة خشبية",
      categoryId: "kitchens",
      price: 385000,
      priceOnRequest: false,
      image: IMG.kitchenHero,
      gallery: [IMG.kitchenHero, IMG.kitchenCream],
      description:
        "جزيرة خشبية رخيصة الارتفاع مع سطح عمل سخي، خزائن سوداء مطفية وأسقف مرتفعة. توزيع مدروس يمنحك مساحة طهي مريحة واستقبالاً للعائلة والأصدقاء.",
      features: [
        "جزيرة خشب بسطح عمل متين",
        "خزائن سوداء مطفية سهلة التنظيف",
        "توزيع مثلث الطهي المدروس",
        "مخطط 2D + تصور 3D مجاني",
      ],
      featured: true,
      createdAt: "2025-10-21T10:00:00.000Z",
    },
    {
      id: "k-gold-classic",
      title: "مطبخ فاخر بلمسات ذهبية",
      categoryId: "kitchens",
      price: 350000,
      priceOnRequest: false,
      image: IMG.kitchenGold,
      gallery: [IMG.kitchenGold],
      description:
        "خامات داكنة ومقابض نحاسية مصقولة مع رخام للأسطح. مزيج بين الكلاسيكية والفخامة المعاصرة، مناسب للمساحات الكبيرة والفيلات.",
      features: [
        "مقابض نحاسية مصقولة",
        "سطح عمل رخامي",
        "إضاءة داخلية للخزائن",
        "تفصيل حسب المقاس",
      ],
      featured: false,
      createdAt: "2025-09-15T10:00:00.000Z",
    },
    {
      id: "k-white-oak",
      title: "مطبخ أبيض وخشب طبيعي",
      categoryId: "kitchens",
      price: 295000,
      priceOnRequest: false,
      image: IMG.kitchenWhite,
      gallery: [IMG.kitchenWhite, IMG.kitchenWood],
      description:
        "مطبخ مضيء بأبواب بيضاء وسطح خشب طبيعي، مثالي للمساحات الصغيرة والمتوسطة. حلول تخزين عمودية تستغل كل سنتيمتر.",
      features: [
        "ألوان فاتحة تزيد الإحساس بالمساحة",
        "تخزين عمودي حتى السقف",
        "أدراج هيدروليكية هادئة",
        "خامات سهلة التنظيف",
      ],
      featured: false,
      createdAt: "2025-08-30T10:00:00.000Z",
    },
    {
      id: "k-marble-dark",
      title: "مطبخ خشب داكن وجزيرة رخام",
      categoryId: "kitchens",
      price: 465000,
      priceOnRequest: false,
      image: IMG.kitchenMarble,
      gallery: [IMG.kitchenMarble, IMG.kitchenHero],
      description:
        "مطبخ فاخر بخزائن خشب داكنة وجزيرة رخام، مع إضاءة دافئة وخطوط نظيفة. مصمم لعشاق الطابع الفندقي في المنزل.",
      features: [
        "جزيرة رخام بسطح واسع",
        "خزائن خشب داكن فاخر",
        "إضاءة خفية دافئة",
        "خزانة نبيذ مدمجة",
      ],
      featured: true,
      createdAt: "2025-07-18T10:00:00.000Z",
    },
    {
      id: "k-warm-paneling",
      title: "مطبخ بجدارية خشبية وإضاءة دافئة",
      categoryId: "kitchens",
      price: 320000,
      priceOnRequest: false,
      image: IMG.kitchenCream,
      gallery: [IMG.kitchenCream],
      description:
        "جدارية خشبية مضاءة، أدراج واسعة ومواد دافئة تمنح المطبخ إحساساً هادئاً ومريحاً. مناسب للمساحات الأفقية والمطابخ المفتوحة على الصالون.",
      features: [
        "جدارية خشبية مع إضاءة LED",
        "أدراج واسعة بسكك هيدروليكية",
        "تنظيم داخلي قابل للتعديل",
        "معاينة وتركيب احترافي",
      ],
      featured: false,
      createdAt: "2025-06-05T10:00:00.000Z",
    },
    {
      id: "d-smoked-glass",
      title: "دريسنج روم بزجاج مدخن وإضاءة",
      categoryId: "dressing",
      price: 265000,
      priceOnRequest: false,
      image: IMG.dressingWood,
      gallery: [IMG.dressingWood, IMG.dressingLed],
      description:
        "دريسنج روم بأبواب زجاج مدخن وإطارات معدنية سوداء، إضاءة LED على كل رف، وأدراج خشب فاتحة مبطنة. يعرض ملابسك كأنها في بوتيك خاص.",
      features: [
        "أبواب زجاج مدخن بإطار أسود",
        "إضاءة LED على كل رف",
        "أدراج مبطنة وأرفف أحذية",
        "رفوف قابلة للتعديل",
      ],
      featured: true,
      createdAt: "2025-11-10T10:00:00.000Z",
    },
    {
      id: "d-vanity-mirror",
      title: "دريسنج بمرآة مضاءة وتسريحة",
      categoryId: "dressing",
      price: 215000,
      priceOnRequest: false,
      image: IMG.dressingBeige,
      gallery: [IMG.dressingBeige, IMG.dressingVanity],
      description:
        "خزائن مطفية بلون الشامبانيا مع وحدة تسريحة رخامية ومرآة بإضاءة خلفية. مزيج بين العملي والفاخر لغرفة النوم الرئيسية.",
      features: [
        "مرآة بإضاءة خلفية دافئة",
        "سطح تسريحة رخامي",
        "مقابض طويلة مطفية",
        "أدراج صغيرة للاكسسوارات",
      ],
      featured: false,
      createdAt: "2025-10-08T10:00:00.000Z",
    },
    {
      id: "d-led-wardrobe",
      title: "خزانة جرارة بإضاءة داخلية",
      categoryId: "dressing",
      price: 240000,
      priceOnRequest: false,
      image: IMG.dressingLed,
      gallery: [IMG.dressingLed],
      description:
        "خزانة بأبواب جرارة تفتح المساحة وتوفّر إضاءة داخلية تلقائية عند الفتح. أرفف للثياب المطوية وأخرى معلقة وأدراج للأحذية.",
      features: [
        "أبواب جرارة توفر المساحة",
        "إضاءة تلقائية داخل الخزانة",
        "مناطق مخصصة للأحذية والحقائب",
        "خشب فاتح وسطح مقاوم للخدش",
      ],
      featured: true,
      createdAt: "2025-09-02T10:00:00.000Z",
    },
    {
      id: "d-linear-light",
      title: "غرفة ملابس بإضاءة خطية",
      categoryId: "dressing",
      price: 330000,
      priceOnRequest: false,
      image: IMG.dressingLoft,
      gallery: [IMG.dressingLoft],
      description:
        "غرفة ملابس كاملة بتصميم مفتوح وإضاءة خطية على الجدران، مع جزيرة صغيرة للاكسسوارات ومساحة للجلوس. تستغل ارتفاع السقف بالكامل.",
      features: [
        "إضاءة خطية على الجدران",
        "جزيرة اكسسوارات مركزية",
        "تخزين حتى السقف",
        "مرايا كاملة الطول",
      ],
      featured: false,
      createdAt: "2025-07-25T10:00:00.000Z",
    },
    {
      id: "d-compact-vanity",
      title: "وحدة تسريحة وخزانة مدمجة",
      categoryId: "dressing",
      price: 158000,
      priceOnRequest: false,
      image: IMG.dressingVanity,
      gallery: [IMG.dressingVanity],
      description:
        "حل ذكي لغرفة نوم متوسطة: خزانة مدمجة مع ركن تسريحة بمرآة مضاءة، تصميم يوفر المساحة ويضيف لمسة فندقية.",
      features: [
        "مرآة بإضاءة LED مدمجة",
        "أدراج ذات أقسام",
        "أرفف ديكور جانبية",
        "مقاسات حسب المساحة المتوفرة",
      ],
      featured: false,
      createdAt: "2025-06-20T10:00:00.000Z",
    },
    {
      id: "o-executive-walnut",
      title: "مكتب تنفيذي خشب داكن",
      categoryId: "offices",
      price: 195000,
      priceOnRequest: false,
      image: IMG.officeExec,
      gallery: [IMG.officeExec, IMG.officeLux],
      description:
        "مكتب تنفيذي بسطح خشب واسع وخزائن مدمجة بإضاءة خلفية. تصميم يمنح مساحة عملك حضوراً قوياً وهادئاً في الوقت نفسه.",
      features: [
        "سطح عمل واسع بخشب داكن",
        "مكتبة مدمجة بإضاءة مخفية",
        "إدارة أسلاك مخفية",
        "مقابض وتفاصيل نحاسية",
      ],
      featured: true,
      createdAt: "2025-11-15T10:00:00.000Z",
    },
    {
      id: "o-home-cabinets",
      title: "مكتب منزلي وجدارية رفوف",
      categoryId: "offices",
      price: 135000,
      priceOnRequest: false,
      image: IMG.officeHome,
      gallery: [IMG.officeHome],
      description:
        "مكتب منزلي عملي مع جدارية معلقة وخزائن أدراج. كل ما تحتاجه للعمل والدراسة في مساحة صغيرة، بدون فوضى.",
      features: [
        "جدارية معلقة فوق المكتب",
        "أدراج عملية وخفية",
        "فتحة لتمديد الأسلاك",
        "خشب طبيعي مقاوم",
      ],
      featured: false,
      createdAt: "2025-10-12T10:00:00.000Z",
    },
    {
      id: "o-library-executive",
      title: "مكتب فاخر مع مكتبة مدمجة",
      categoryId: "offices",
      price: 178000,
      priceOnRequest: false,
      image: IMG.officeLux,
      gallery: [IMG.officeLux, IMG.officeExec],
      description:
        "مكتب بخامات دافئة ومكتبة كاملة الحائط بإضاءة دافئة. مناسب للمكاتب المهنية والمديرين، ويُصنع حسب أبعاد الغرفة.",
      features: [
        "مكتبة كاملة الحائط",
        "إضاءة رفوف دافئة",
        "خزائن سفلية للأرشيف",
        "تشطيب فاخر مقاوم للاستعمال",
      ],
      featured: true,
      createdAt: "2025-09-28T10:00:00.000Z",
    },
    {
      id: "o-minimal-small",
      title: "مكتب مينيمال لمساحة صغيرة",
      categoryId: "offices",
      price: 142000,
      priceOnRequest: false,
      image: IMG.officeModern,
      gallery: [IMG.officeModern],
      description:
        "مكتب وجدارية رفوف بخطوط نظيفة يناسب زاوية الغرفة أو الشرفة المغلقة. حل خفيف وأنيق للعمل من المنزل.",
      features: [
        "تصميم خفيف يناسب الزوايا",
        "رفوف مفتوحة للكتب",
        "أدراج هادئة الحركة",
        "مقاسات مرنة",
      ],
      featured: false,
      createdAt: "2025-08-14T10:00:00.000Z",
    },
  ],
};
