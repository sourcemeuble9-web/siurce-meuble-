export type Category = {
  id: string;
  name: string;
  englishName: string;
  tagline: string;
  description: string;
  image: string;
};

export type Product = {
  id: string;
  title: string;
  categoryId: string;
  price: number;
  priceOnRequest: boolean;
  image: string;
  gallery: string[];
  description: string;
  features: string[];
  featured: boolean;
  createdAt: string;
};

export type SiteSettings = {
  companyName: string;
  tagline: string;
  phone: string;
  whatsapp: string;
  mapUrl: string;
  address: string;
  email: string;
  instagram: string;
  facebook: string;

  heroBadge: string;
  heroTitle: string;
  heroHighlight: string;
  heroSubtitle: string;
  heroImage: string;

  planningTitle: string;
  planningSubtitle: string;
  planningPoints: string[];

  aboutTitle: string;
  aboutText: string;
  aboutImage: string;

  yearsExperience: number;
  projectsCount: number;
  clientsCount: number;
};

export type SiteData = {
  version: number;
  settings: SiteSettings;
  categories: Category[];
  products: Product[];
};

export type NewProduct = Omit<Product, "id" | "createdAt">;
