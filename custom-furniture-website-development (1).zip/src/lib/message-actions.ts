"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/db";
import { messages } from "@/db/schema";

export type ContactState = {
  status: "idle" | "success" | "error";
  message?: string;
};

export async function submitContactMessage(
  _prevState: ContactState,
  formData: FormData,
): Promise<ContactState> {
  const name = String(formData.get("name") || "").trim();
  const phone = String(formData.get("phone") || "").trim();
  const projectType = String(formData.get("projectType") || "").trim();
  const content = String(formData.get("content") || "").trim();

  if (name.length < 2 || phone.length < 6 || content.length < 4) {
    return {
      status: "error",
      message: "يرجى تعبئة الاسم، رقم هاتف صحيح، وتفاصيل الطلب.",
    };
  }

  try {
    await db.insert(messages).values({
      name,
      phone,
      content: projectType ? `[${projectType}] ${content}` : content,
    });
    revalidatePath("/");
    return {
      status: "success",
      message: "تم إرسال طلبك بنجاح. سنتواصل معك قريباً على الرقم الذي أدخلته.",
    };
  } catch {
    return {
      status: "error",
      message: "حدث خطأ أثناء الإرسال. جرّب مرة أخرى أو راسلنا على واتساب.",
    };
  }
}
