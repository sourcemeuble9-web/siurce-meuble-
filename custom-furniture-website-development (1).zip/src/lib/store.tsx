"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { DEFAULT_DATA } from "./seed";
import { createId } from "./format";
import type { Category, NewProduct, Product, SiteData, SiteSettings } from "./types";

export const STORAGE_KEY = "source-meuble:data:v1";
export const ADMIN_UNLOCK_KEY = "source-meuble:admin:v1";
export const ADMIN_PASSCODE = process.env.NEXT_PUBLIC_ADMIN_PASSCODE || "SourceMeuble2024";

type SiteContextValue = {
  data: SiteData;
  ready: boolean;
  status: { kind: "ok" | "warn"; text: string } | null;

  adminOpen: boolean;
  openAdmin: () => void;
  closeAdmin: () => void;
  adminKey: string | null;
  unlockAdmin: (password: string) => boolean;
  lockAdmin: () => void;

  galleryFilter: string;
  setGalleryFilter: (value: string) => void;
  activeProduct: Product | null;
  openProduct: (product: Product) => void;
  closeProduct: () => void;

  addProduct: (product: NewProduct) => void;
  updateProduct: (id: string, product: NewProduct) => void;
  deleteProduct: (id: string) => void;
  updateCategory: (id: string, patch: Partial<Category>) => void;
  updateSettings: (patch: Partial<SiteSettings>) => void;
  replaceData: (next: SiteData) => void;
  resetData: () => void;
  notify: (text: string, kind?: "ok" | "warn") => void;
};

const SiteContext = createContext<SiteContextValue | null>(null);

function normalize(raw: unknown): SiteData | null {
  if (!raw || typeof raw !== "object") return null;
  const candidate = raw as Partial<SiteData>;
  const settings = { ...DEFAULT_DATA.settings, ...(candidate.settings ?? {}) };
  const categories = Array.isArray(candidate.categories)
    ? candidate.categories.filter((c): c is Category => Boolean(c && typeof c.id === "string"))
    : DEFAULT_DATA.categories;
  const products = Array.isArray(candidate.products)
    ? candidate.products
        .filter((p): p is Product => Boolean(p && typeof p.id === "string"))
        .map((p) => ({
          ...p,
          gallery: Array.isArray(p.gallery) ? p.gallery.filter(Boolean) : [],
          features: Array.isArray(p.features) ? p.features.filter(Boolean) : [],
          price: Number.isFinite(Number(p.price)) ? Number(p.price) : 0,
        }))
    : DEFAULT_DATA.products;

  return {
    version: 1,
    settings,
    categories: categories.length > 0 ? categories : DEFAULT_DATA.categories,
    products,
  };
}

export function SiteDataProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<SiteData>(DEFAULT_DATA);
  const [ready, setReady] = useState(false);
  const [status, setStatus] = useState<{ kind: "ok" | "warn"; text: string } | null>(null);
  const [adminOpen, setAdminOpen] = useState(false);
  const [adminKey, setAdminKey] = useState<string | null>(null);
  const [galleryFilter, setGalleryFilter] = useState("all");
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);

  // Load persisted content on the client only (avoids hydration mismatch).
  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = normalize(JSON.parse(stored));
        if (parsed) setData(parsed);
      }
      const unlocked = window.sessionStorage.getItem(ADMIN_UNLOCK_KEY);
      if (unlocked) setAdminKey(unlocked);
      const params = new URLSearchParams(window.location.search);
      if (params.get("admin") === "1") setAdminOpen(true);
    } catch {
      // corrupted storage — keep defaults
    } finally {
      setReady(true);
    }
  }, []);

  const persist = useCallback((next: SiteData) => {
    setData(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      setStatus({
        kind: "warn",
        text: "تعذر الحفظ في المتصفح (المساحة ممتلئة). جرّب صوراً أصغر أو استخدم روابط صور.",
      });
      return;
    }
    setStatus({ kind: "ok", text: "تم الحفظ في متصفحك ✓" });
  }, []);

  useEffect(() => {
    if (!status) return;
    const timer = window.setTimeout(() => setStatus(null), 3500);
    return () => window.clearTimeout(timer);
  }, [status]);

  useEffect(() => {
    if (!activeProduct) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setActiveProduct(null);
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [activeProduct]);

  useEffect(() => {
    if (!adminOpen) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setAdminOpen(false);
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [adminOpen]);

  const value = useMemo<SiteContextValue>(() => {
    const notify = (text: string, kind: "ok" | "warn" = "ok") => setStatus({ kind, text });

    return {
      data,
      ready,
      status,
      adminOpen,
      openAdmin: () => setAdminOpen(true),
      closeAdmin: () => setAdminOpen(false),
      adminKey,
      unlockAdmin: (password: string) => {
        if (password.trim() === ADMIN_PASSCODE) {
          setAdminKey(password.trim());
          try {
            window.sessionStorage.setItem(ADMIN_UNLOCK_KEY, password.trim());
          } catch {
            // ignore storage errors
          }
          return true;
        }
        return false;
      },
      lockAdmin: () => {
        setAdminKey(null);
        setAdminOpen(false);
        try {
          window.sessionStorage.removeItem(ADMIN_UNLOCK_KEY);
        } catch {
          // ignore
        }
      },
      galleryFilter,
      setGalleryFilter,
      activeProduct,
      openProduct: (product: Product) => setActiveProduct(product),
      closeProduct: () => setActiveProduct(null),
      addProduct: (product: NewProduct) => {
        const created: Product = {
          ...product,
          id: createId(product.categoryId || "product"),
          createdAt: new Date().toISOString(),
        };
        persist({ ...data, products: [created, ...data.products] });
        notify("تمت إضافة المنتج وحفظه في المتصفح ✓");
      },
      updateProduct: (id: string, product: NewProduct) => {
        persist({
          ...data,
          products: data.products.map((p) => (p.id === id ? { ...p, ...product } : p)),
        });
        setActiveProduct((current) => (current && current.id === id ? { ...current, ...product } : current));
        notify("تم تحديث المنتج ✓");
      },
      deleteProduct: (id: string) => {
        persist({ ...data, products: data.products.filter((p) => p.id !== id) });
        notify("تم حذف المنتج");
      },
      updateCategory: (id: string, patch: Partial<Category>) => {
        persist({
          ...data,
          categories: data.categories.map((c) => (c.id === id ? { ...c, ...patch } : c)),
        });
        notify("تم تحديث الفئة ✓");
      },
      updateSettings: (patch: Partial<SiteSettings>) => {
        persist({ ...data, settings: { ...data.settings, ...patch } });
        notify("تم حفظ الإعدادات في المتصفح ✓");
      },
      replaceData: (next: SiteData) => {
        const normalized = normalize(next);
        if (!normalized) {
          notify("الملف غير صالح", "warn");
          return;
        }
        persist(normalized);
        notify("تم استيراد البيانات بنجاح ✓");
      },
      resetData: () => {
        persist(DEFAULT_DATA);
        notify("تمت استعادة المحتوى الافتراضي");
      },
      notify,
    };
  }, [data, ready, status, adminOpen, adminKey, galleryFilter, activeProduct, persist]);

  return <SiteContext.Provider value={value}>{children}</SiteContext.Provider>;
}

export function useSite(): SiteContextValue {
  const context = useContext(SiteContext);
  if (!context) throw new Error("useSite must be used inside SiteDataProvider");
  return context;
}
