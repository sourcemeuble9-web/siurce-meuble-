export function formatPrice(value: number): string {
  return new Intl.NumberFormat("fr-FR").format(Math.max(0, Math.round(value)));
}

export function toWhatsAppLink(phone: string, message?: string): string {
  const digits = (phone || "").replace(/\D/g, "");
  const international = digits.startsWith("0") ? `213${digits.slice(1)}` : digits;
  const base = `https://wa.me/${international}`;
  return message ? `${base}?text=${encodeURIComponent(message)}` : base;
}

export function toTelLink(phone: string): string {
  return `tel:${(phone || "").replace(/\s+/g, "")}`;
}

export function createId(prefix = "item"): string {
  const random = Math.random().toString(36).slice(2, 8);
  return `${prefix}-${Date.now().toString(36)}-${random}`;
}

export function priceLabel(price: number, onRequest: boolean): string {
  if (onRequest) return "السعر عند الطلب";
  return `${formatPrice(price)} دج`;
}
