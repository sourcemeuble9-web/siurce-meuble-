import { sql } from "drizzle-orm";
import {
  boolean,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description"),
  imageUrl: text("image_url"),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  categoryId: integer("category_id").references(() => categories.id, {
    onDelete: "set null",
  }),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description"),
  imageUrl: text("image_url"),
  gallery: jsonb("gallery")
    .$type<string[]>()
    .notNull()
    .default(sql`'[]'::jsonb`),
  price: integer("price").notNull().default(0),
  isStartingPrice: boolean("is_starting_price").notNull().default(false),
  showPriceOnRequest: boolean("show_price_on_request").notNull().default(false),
  featured: boolean("featured").notNull().default(false),
  available: boolean("available").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const siteSettings = pgTable("site_settings", {
  id: serial("id").primaryKey(),
  companyName: text("company_name").notNull().default("Source Meuble"),
  tagline: text("tagline").notNull().default("مطابخ عصرية - دريسينغ - مكاتب حسب الطلب"),
  phone: text("phone").notNull().default("0550808843"),
  whatsapp: text("whatsapp").notNull().default("0550808843"),
  mapUrl: text("map_url").notNull().default("https://maps.app.goo.gl/SmXT1y4o9eNJnhxs6"),
  address: text("address").notNull().default("الجزائر"),
  heroTitle: text("hero_title").notNull().default("Source Meuble"),
  heroSubtitle: text("hero_subtitle").notNull().default(
    "نصنع لكم مطابخ، دريسينغ ومكاتب على القياس بجودة عالية وتصاميم عصرية تناسب ذوقكم ومساحتكم",
  ),
  heroImageUrl: text("hero_image_url").notNull().default("/images/hero.jpg"),
  aboutTitle: text("about_title").notNull().default("من نحن"),
  aboutText: text("about_text").notNull().default(
    "Source Meuble ورشة جزائرية متخصصة في تصنيع وتركيب المطابخ والدريسينغ والمكاتب حسب الطلب. نعتمد على خامات عالية الجودة ويد عاملة ماهرة لنقدم لكم أثاثاً يجمع بين الجمال والمتانة، مصمماً خصيصاً ليلائم مساحتكم وذوقكم.",
  ),
  aboutImageUrl: text("about_image_url").notNull().default("/images/about.jpg"),
  facebookUrl: text("facebook_url"),
  instagramUrl: text("instagram_url"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  content: text("content").notNull(),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
