"use client";

import { useCallback, useEffect, useState } from "react";
import { useSite } from "@/lib/store";
import { toTelLink, toWhatsAppLink } from "@/lib/format";
import { WhatsAppIcon } from "@/components/site/Navbar";

type MessageRow = {
  id: number;
  name: string;
  phone: string;
  content: string;
  read: boolean;
  createdAt: string;
};

export function MessagesTab() {
  const { adminKey, notify } = useSite();
  const [messages, setMessages] = useState<MessageRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const call = useCallback(
    async (action: "list" | "delete" | "toggleRead", extra: Record<string, unknown> = {}) => {
      if (!adminKey) return;
      setLoading(true);
      setError("");
      try {
        const response = await fetch("/api/admin/messages", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ password: adminKey, action, ...extra }),
        });
        if (!response.ok) {
          throw new Error(response.status === 401 ? "unauthorized" : "failed");
        }
        const payload = (await response.json()) as { messages: MessageRow[] };
        setMessages(Array.isArray(payload.messages) ? payload.messages : []);
      } catch (err) {
        setError(
          err instanceof Error && err.message === "unauthorized"
            ? "كلمة المرور غير مطابقة لكلمة مرور الخادم، أعد فتح اللوحة."
            : "تعذر تحميل الرسائل من الخادم.",
        );
      } finally {
        setLoading(false);
      }
    },
    [adminKey],
  );

  useEffect(() => {
    void call("list");
  }, [call]);

  const unread = messages.filter((message) => !message.read).length;

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-sm font-extrabold text-cream">
            رسائل العملاء {unread > 0 && <span className="text-bronze-300">({unread} جديدة)</span>}
          </h3>
          <p className="mt-1 text-[11px] text-muted">
            الطلبات المرسلة من نموذج التواصل — محفوظة في قاعدة البيانات وتظهر على الرابط.
          </p>
        </div>
        <button
          type="button"
          onClick={() => void call("list")}
          className="rounded-lg border border-line-soft px-3.5 py-2 text-[10px] font-bold text-cream/80 transition hover:border-bronze-500"
        >
          تحديث ⟳
        </button>
      </div>

      {loading && <p className="rounded-xl border border-line bg-ink-850 p-6 text-center text-xs text-muted">جاري التحميل...</p>}
      {error && (
        <p className="rounded-xl border border-red-500/30 bg-red-500/10 p-4 text-center text-xs font-semibold text-red-300">
          {error}
        </p>
      )}

      {!loading && !error && messages.length === 0 && (
        <p className="rounded-xl border border-line bg-ink-850 p-8 text-center text-xs text-muted">
          لا توجد رسائل بعد. الرسائل الجديدة من الموقع ستظهر هنا.
        </p>
      )}

      <div className="flex flex-col gap-3">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`rounded-xl border p-4 ${
              message.read ? "border-line bg-ink-850" : "border-bronze-500/40 bg-ink-800"
            }`}
          >
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <p className="text-xs font-extrabold text-cream">
                  {message.name}
                  {!message.read && (
                    <span className="mr-2 rounded-full bg-bronze-500 px-2 py-0.5 text-[9px] font-bold text-ink-950">
                      جديد
                    </span>
                  )}
                </p>
                <a href={toTelLink(message.phone)} dir="ltr" className="text-[11px] text-muted hover:text-cream">
                  {message.phone}
                </a>
              </div>
              <span className="text-[10px] text-muted">
                {new Date(message.createdAt).toLocaleString("fr-DZ", {
                  dateStyle: "short",
                  timeStyle: "short",
                })}
              </span>
            </div>
            <p className="mt-2 text-[11px] leading-6 text-cream/85">{message.content}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <a
                href={toWhatsAppLink(message.phone, `مرحباً ${message.name}، بخصوص طلبك من Source Meuble...`)}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#25D366]/15 px-3 py-1.5 text-[10px] font-bold text-[#4ade80] transition hover:bg-[#25D366]/25"
              >
                <WhatsAppIcon className="h-3 w-3" />
                رد عبر واتساب
              </a>
              <button
                type="button"
                onClick={async () => {
                  await call("toggleRead", { id: message.id, read: !message.read });
                  notify(!message.read ? "تم وسمها كمقروءة" : "تم وسمها كغير مقروءة");
                }}
                className="rounded-lg border border-line-soft px-3 py-1.5 text-[10px] font-bold text-cream/80 transition hover:border-bronze-500"
              >
                {message.read ? "غير مقروءة" : "مقروءة"}
              </button>
              <button
                type="button"
                onClick={async () => {
                  if (!window.confirm("حذف هذه الرسالة نهائياً؟")) return;
                  await call("delete", { id: message.id });
                  notify("تم حذف الرسالة");
                }}
                className="rounded-lg border border-red-500/30 px-3 py-1.5 text-[10px] font-bold text-red-300 transition hover:bg-red-500/10"
              >
                حذف
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
