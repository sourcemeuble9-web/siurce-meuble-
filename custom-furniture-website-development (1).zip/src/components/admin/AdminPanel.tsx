"use client";

import { useEffect, useState } from "react";
import { useSite } from "@/lib/store";
import { LogoMark } from "@/components/site/Logo";
import { ProductsTab } from "./ProductsTab";
import { CategoriesTab } from "./CategoriesTab";
import { SettingsTab } from "./SettingsTab";
import { MessagesTab } from "./MessagesTab";
import { BackupTab } from "./BackupTab";

type TabId = "products" | "categories" | "settings" | "messages" | "backup";

const TABS: { id: TabId; label: string; icon: string }[] = [
  { id: "products", label: "المنتجات", icon: "🛋️" },
  { id: "categories", label: "الفئات", icon: "🗂️" },
  { id: "settings", label: "إعدادات الموقع", icon: "⚙️" },
  { id: "messages", label: "الرسائل", icon: "✉️" },
  { id: "backup", label: "النسخ الاحتياطي", icon: "💾" },
];

export function AdminPanel() {
  const { adminOpen, closeAdmin, adminKey, unlockAdmin, lockAdmin, status, data } = useSite();
  const [tab, setTab] = useState<TabId>("products");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [showHint, setShowHint] = useState(false);

  useEffect(() => {
    if (adminOpen) {
      setPassword("");
      setError("");
    }
  }, [adminOpen]);

  if (!adminOpen) return null;

  const submitPassword = () => {
    const success = unlockAdmin(password);
    if (!success) {
      setError("كلمة المرور غير صحيحة. حاول مرة أخرى.");
      return;
    }
    setError("");
    setPassword("");
  };

  return (
    <div
      className="fixed inset-0 z-[80] flex items-end justify-center bg-black/85 backdrop-blur-md sm:items-center sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label="لوحة التحكم"
      onClick={closeAdmin}
    >
      <div
        className="relative flex max-h-[94vh] w-full max-w-6xl flex-col overflow-hidden rounded-t-3xl border border-line bg-ink-900 shadow-2xl sm:rounded-3xl"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 border-b border-line bg-ink-950 px-5 py-4">
          <div className="flex items-center gap-3">
            <LogoMark className="h-9 w-9" />
            <div>
              <h2 className="text-sm font-extrabold text-cream">لوحة تحكم {data.settings.companyName}</h2>
              <p className="mt-0.5 text-[10px] text-muted">
                {adminKey ? "تحكم كامل في المنتجات، الصور، الأسعار والتواصل" : "الوصول محمي — أدخل كلمة المرور"}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {adminKey && (
              <button
                type="button"
                onClick={lockAdmin}
                className="rounded-lg border border-line-soft px-3 py-1.5 text-[10px] font-bold text-muted transition hover:border-bronze-500 hover:text-cream"
              >
                قفل
              </button>
            )}
            <button
              type="button"
              onClick={closeAdmin}
              aria-label="إغلاق"
              className="flex h-8 w-8 items-center justify-center rounded-full border border-line-soft text-cream transition hover:border-bronze-500"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" d="M6 6l12 12M18 6L6 18" />
              </svg>
            </button>
          </div>
        </div>

        {!adminKey ? (
          <div className="flex flex-1 items-center justify-center px-5 py-14">
            <div className="w-full max-w-sm text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-bronze-500/35 bg-bronze-500/10">
                <svg viewBox="0 0 24 24" className="h-7 w-7 text-bronze-300" fill="none" stroke="currentColor" strokeWidth="1.6">
                  <rect x="4" y="10" width="16" height="10" rx="2" />
                  <path d="M8 10V7a4 4 0 0 1 8 0v3" strokeLinecap="round" />
                </svg>
              </div>
              <h3 className="mt-4 text-base font-extrabold text-cream">أدخل كلمة المرور</h3>
              <p className="mt-1.5 text-[11px] leading-6 text-muted">
                هذه اللوحة تسمح لك بإضافة وتعديل المنتجات والأسعار وتغيير رقم الهاتف ورابط الخريطة.
              </p>
              <form
                onSubmit={(event) => {
                  event.preventDefault();
                  submitPassword();
                }}
                className="mt-5 flex flex-col gap-2.5"
              >
                <input
                  type="password"
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  placeholder="كلمة المرور"
                  autoFocus
                  className="field text-center"
                />
                <button type="submit" className="btn-gold w-full">
                  فتح لوحة التحكم
                </button>
              </form>
              {error && <p className="mt-2 text-[11px] font-semibold text-red-300">{error}</p>}
              <button
                type="button"
                onClick={() => setShowHint((value) => !value)}
                className="mt-4 text-[10px] font-semibold text-muted underline-offset-4 hover:text-bronze-300 hover:underline"
              >
                نسيت كلمة المرور؟
              </button>
              {showHint && (
                <p className="mt-2 rounded-lg border border-line bg-ink-850 px-3 py-2 text-[10px] leading-5 text-muted">
                  كلمة المرور يحدّدها مالك الموقع في متغير البيئة{" "}
                  <code dir="ltr" className="text-bronze-300">
                    NEXT_PUBLIC_ADMIN_PASSCODE
                  </code>{" "}
                  (ويجب أن تكون مطابقة لـ{" "}
                  <code dir="ltr" className="text-bronze-300">
                    ADMIN_PASSWORD
                  </code>
                  ). راجع ملف <code dir="ltr">.env.local</code> أو إعدادات الاستضافة.
                </p>
              )}
            </div>
          </div>
        ) : (
          <>
            <div className="no-scrollbar flex gap-1.5 overflow-x-auto border-b border-line px-3 py-2.5">
              {TABS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setTab(item.id)}
                  className={`shrink-0 rounded-lg px-3.5 py-2 text-[11px] font-bold transition ${
                    tab === item.id
                      ? "bg-gradient-to-l from-bronze-400 to-bronze-600 text-ink-950"
                      : "text-muted hover:bg-ink-850 hover:text-cream"
                  }`}
                >
                  <span className="mr-1">{item.icon}</span>
                  {item.label}
                </button>
              ))}
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-5">
              {tab === "products" && <ProductsTab />}
              {tab === "categories" && <CategoriesTab />}
              {tab === "settings" && <SettingsTab />}
              {tab === "messages" && <MessagesTab />}
              {tab === "backup" && <BackupTab />}
            </div>
          </>
        )}

        {status && (
          <div
            className={`absolute bottom-4 left-1/2 z-10 -translate-x-1/2 rounded-full border px-4 py-2 text-[11px] font-bold shadow-xl ${
              status.kind === "ok"
                ? "border-green-500/40 bg-green-950/95 text-green-200"
                : "border-red-500/40 bg-red-950/95 text-red-200"
            }`}
          >
            {status.text}
          </div>
        )}
      </div>
    </div>
  );
}
