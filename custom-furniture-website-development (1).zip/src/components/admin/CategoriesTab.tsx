"use client";

import { useState } from "react";
import { useSite } from "@/lib/store";
import type { Category } from "@/lib/types";
import { ImagePicker, TextField } from "./Fields";

function CategoryEditor({ category }: { category: Category }) {
  const { updateCategory } = useSite();
  const [draft, setDraft] = useState(category);

  const patch = (values: Partial<Category>) => setDraft((current) => ({ ...current, ...values }));
  const changed = JSON.stringify(draft) !== JSON.stringify(category);

  return (
    <div className="rounded-xl border border-line bg-ink-850 p-4">
      <div className="mb-3 flex items-center justify-between">
        <h4 className="text-xs font-extrabold text-cream">{category.name}</h4>
        <span className="font-display text-[10px] tracking-[0.18em] text-bronze-400">
          {category.englishName}
        </span>
      </div>
      <div className="grid gap-3">
        <TextField label="الاسم بالعربية" value={draft.name} onChange={(value) => patch({ name: value })} />
        <TextField
          label="الاسم بالإنجليزية"
          value={draft.englishName}
          dir="ltr"
          onChange={(value) => patch({ englishName: value })}
        />
        <TextField label="السطر التعريفي" value={draft.tagline} onChange={(value) => patch({ tagline: value })} />
        <TextField label="الوصف" value={draft.description} onChange={(value) => patch({ description: value })} />
        <ImagePicker label="صورة الفئة" value={draft.image} onChange={(value) => patch({ image: value })} />
      </div>
      <button
        type="button"
        disabled={!changed}
        onClick={() => updateCategory(category.id, draft)}
        className="btn-gold mt-4 w-full !py-2 text-[11px] disabled:cursor-not-allowed disabled:opacity-40"
      >
        حفظ الفئة
      </button>
    </div>
  );
}

export function CategoriesTab() {
  const { data } = useSite();

  return (
    <div>
      <h3 className="text-sm font-extrabold text-cream">الفئات ({data.categories.length})</h3>
      <p className="mt-1 text-[11px] text-muted">
        عدّل أسماء الفئات (المطابخ، الدريسنج، المكاتب) وصورها وسطورها التعريفية.
      </p>
      <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {data.categories.map((category) => (
          <CategoryEditor key={`${category.id}-${category.name}`} category={category} />
        ))}
      </div>
    </div>
  );
}
