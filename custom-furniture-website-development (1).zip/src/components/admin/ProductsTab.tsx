"use client";

import { useState } from "react";
import { useSite } from "@/lib/store";
import type { NewProduct, Product } from "@/lib/types";
import { priceLabel } from "@/lib/format";
import { ProductForm } from "./ProductForm";

function emptyProduct(categoryId: string): NewProduct {
  return {
    title: "",
    categoryId,
    price: 0,
    priceOnRequest: false,
    image: "",
    gallery: [],
    description: "",
    features: [],
    featured: false,
  };
}

export function ProductsTab() {
  const { data, addProduct, updateProduct, deleteProduct } = useSite();
  const [editing, setEditing] = useState<{ mode: "new" } | { mode: "edit"; product: Product } | null>(null);

  const categoryName = (id: string) => data.categories.find((c) => c.id === id)?.name ?? "—";

  if (editing) {
    const isNew = editing.mode === "new";
    const initial: NewProduct = isNew
      ? emptyProduct(data.categories[0]?.id ?? "kitchens")
      : {
          title: editing.product.title,
          categoryId: editing.product.categoryId,
          price: editing.product.price,
          priceOnRequest: editing.product.priceOnRequest,
          image: editing.product.image,
          gallery: editing.product.gallery,
          description: editing.product.description,
          features: editing.product.features,
          featured: editing.product.featured,
        };

    return (
      <ProductForm
        initial={initial}
        categories={data.categories}
        onCancel={() => setEditing(null)}
        onSubmit={(values) => {
          if (isNew) {
            addProduct(values);
          } else {
            updateProduct(editing.product.id, values);
          }
          setEditing(null);
        }}
      />
    );
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-sm font-extrabold text-cream">المنتجات ({data.products.length})</h3>
          <p className="mt-1 text-[11px] text-muted">أضف، عدّل أو احذف أي قطعة تظهر في المعرض.</p>
        </div>
        <button type="button" onClick={() => setEditing({ mode: "new" })} className="btn-gold !px-5 !py-2.5 text-xs">
          + منتج جديد
        </button>
      </div>

      <div className="flex flex-col gap-2.5">
        {data.products.map((product) => (
          <div
            key={product.id}
            className="flex flex-wrap items-center gap-3 rounded-xl border border-line bg-ink-850 p-3"
          >
            <div className="h-16 w-20 shrink-0 overflow-hidden rounded-lg border border-line-soft bg-ink-950">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={product.image} alt={product.title} className="h-full w-full object-cover" />
            </div>
            <div className="min-w-[140px] flex-1">
              <div className="flex items-center gap-2">
                <h4 className="text-xs font-extrabold text-cream">{product.title}</h4>
                {product.featured && <span className="text-[10px] text-bronze-400">★ مميز</span>}
              </div>
              <p className="mt-1 text-[10px] text-muted">
                {categoryName(product.categoryId)} · {priceLabel(product.price, product.priceOnRequest)}
              </p>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setEditing({ mode: "edit", product })}
                className="rounded-lg border border-line-soft px-3 py-1.5 text-[10px] font-bold text-cream/85 transition hover:border-bronze-500 hover:text-bronze-300"
              >
                تعديل
              </button>
              <button
                type="button"
                onClick={() => {
                  if (window.confirm(`حذف "${product.title}"؟ لا يمكن التراجع.`)) {
                    deleteProduct(product.id);
                  }
                }}
                className="rounded-lg border border-red-500/30 px-3 py-1.5 text-[10px] font-bold text-red-300 transition hover:bg-red-500/10"
              >
                حذف
              </button>
            </div>
          </div>
        ))}

        {data.products.length === 0 && (
          <p className="rounded-xl border border-line bg-ink-850 p-8 text-center text-xs text-muted">
            لا توجد منتجات. ابدأ بإضافة أول منتج.
          </p>
        )}
      </div>
    </div>
  );
}
