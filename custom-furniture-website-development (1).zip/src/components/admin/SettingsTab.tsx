"use client";

import { useState } from "react";
import { useSite } from "@/lib/store";
import type { SiteSettings } from "@/lib/types";
import { ImagePicker, TextAreaField, TextField } from "./Fields";

export function SettingsTab() {
  const { data, updateSettings } = useSite();
  const [draft, setDraft] = useState<SiteSettings>(data.settings);
  const [pointsText, setPointsText] = useState(data.settings.planningPoints.join("\n"));

  const patch = (values: Partial<SiteSettings>) => setDraft((current) => ({ ...current, ...values }));

  const save = () => {
    updateSettings({
      ...draft,
      phone: draft.phone.trim(),
      whatsapp: (draft.whatsapp.trim() || draft.phone.trim()),
      planningPoints: pointsText
        .split("\n")
        .map((line) => line.trim())
        .filter(Boolean),
      yearsExperience: Number(draft.yearsExperience) || 0,
      projectsCount: Number(draft.projectsCount) || 0,
      clientsCount: Number(draft.clientsCount) || 0,
    });
  };

  return (
    <div className="flex flex-col gap-5">
      <section className="rounded-2xl border border-line bg-ink-850 p-5">
        <h3 className="mb-4 text-sm font-extrabold text-cream">الهوية والتواصل</h3>
        <div className="grid gap-4 md:grid-cols-2">
          <TextField
            label="اسم الشركة"
            value={draft.companyName}
            onChange={(value) => patch({ companyName: value })}
          />
          <TextField
            label="الشعار الفرعي"
            value={draft.tagline}
            onChange={(value) => patch({ tagline: value })}
          />
          <TextField
            label="رقم الهاتف *"
            value={draft.phone}
            dir="ltr"
            onChange={(value) => patch({ phone: value })}
            hint="يُستعمل في أزرار الاتصال في كل الموقع."
          />
          <TextField
            label="رقم الواتساب *"
            value={draft.whatsapp}
            dir="ltr"
            onChange={(value) => patch({ whatsapp: value })}
            hint="الصيغة المحلية 05XXXXXXXX تُحوّل تلقائياً إلى +213."
          />
          <TextField
            label="رابط خرائط Google"
            value={draft.mapUrl}
            dir="ltr"
            onChange={(value) => patch({ mapUrl: value })}
            hint="يُفتح عند الضغط على زر الموقع."
          />
          <TextField
            label="العنوان النصي"
            value={draft.address}
            onChange={(value) => patch({ address: value })}
          />
          <TextField
            label="البريد الإلكتروني"
            value={draft.email}
            dir="ltr"
            onChange={(value) => patch({ email: value })}
          />
          <TextField
            label="إنستغرام"
            value={draft.instagram}
            dir="ltr"
            onChange={(value) => patch({ instagram: value })}
          />
          <TextField
            label="فيسبوك"
            value={draft.facebook}
            dir="ltr"
            onChange={(value) => patch({ facebook: value })}
          />
        </div>
      </section>

      <section className="rounded-2xl border border-line bg-ink-850 p-5">
        <h3 className="mb-4 text-sm font-extrabold text-cream">القسم الرئيسي (Hero)</h3>
        <div className="grid gap-4 md:grid-cols-2">
          <TextField
            label="الشارة العلوية"
            value={draft.heroBadge}
            onChange={(value) => patch({ heroBadge: value })}
          />
          <TextField
            label="العنوان الرئيسي"
            value={draft.heroTitle}
            onChange={(value) => patch({ heroTitle: value })}
          />
          <TextField
            label="السطر الذهبي"
            value={draft.heroHighlight}
            onChange={(value) => patch({ heroHighlight: value })}
          />
          <div className="md:col-span-2">
            <TextAreaField
              label="الوصف الرئيسي"
              value={draft.heroSubtitle}
              onChange={(value) => patch({ heroSubtitle: value })}
              rows={3}
            />
          </div>
          <div className="md:col-span-2">
            <ImagePicker
              label="صورة الواجهة"
              value={draft.heroImage}
              onChange={(value) => patch({ heroImage: value })}
            />
          </div>
        </div>
      </section>

      <section className="rounded-2xl border border-line bg-ink-850 p-5">
        <h3 className="mb-4 text-sm font-extrabold text-cream">خدمة التخطيط 2D / 3D</h3>
        <div className="grid gap-4">
          <TextField
            label="عنوان الخدمة"
            value={draft.planningTitle}
            onChange={(value) => patch({ planningTitle: value })}
          />
          <TextAreaField
            label="وصف الخدمة"
            value={draft.planningSubtitle}
            onChange={(value) => patch({ planningSubtitle: value })}
            rows={3}
          />
          <TextAreaField
            label="مراحل الخدمة (مرحلة في كل سطر)"
            value={pointsText}
            onChange={setPointsText}
            rows={4}
          />
        </div>
      </section>

      <section className="rounded-2xl border border-line bg-ink-850 p-5">
        <h3 className="mb-4 text-sm font-extrabold text-cream">من نحن والأرقام</h3>
        <div className="grid gap-4 md:grid-cols-2">
          <TextField
            label="عنوان من نحن"
            value={draft.aboutTitle}
            onChange={(value) => patch({ aboutTitle: value })}
          />
          <div className="grid grid-cols-3 gap-2">
            <TextField
              label="سنوات الخبرة"
              type="number"
              value={draft.yearsExperience}
              onChange={(value) => patch({ yearsExperience: Number(value) || 0 })}
            />
            <TextField
              label="المشاريع"
              type="number"
              value={draft.projectsCount}
              onChange={(value) => patch({ projectsCount: Number(value) || 0 })}
            />
            <TextField
              label="العملاء"
              type="number"
              value={draft.clientsCount}
              onChange={(value) => patch({ clientsCount: Number(value) || 0 })}
            />
          </div>
          <div className="md:col-span-2">
            <TextAreaField
              label="نص من نحن"
              value={draft.aboutText}
              onChange={(value) => patch({ aboutText: value })}
              rows={4}
            />
          </div>
          <div className="md:col-span-2">
            <ImagePicker
              label="صورة قسم من نحن"
              value={draft.aboutImage}
              onChange={(value) => patch({ aboutImage: value })}
            />
          </div>
        </div>
      </section>

      <div className="sticky bottom-0 -mx-1 flex items-center justify-between gap-3 rounded-xl border border-line bg-ink-900/95 px-4 py-3 backdrop-blur">
        <p className="text-[10px] text-muted">تُحفظ التغييرات في متصفحك مباشرة.</p>
        <button type="button" onClick={save} className="btn-gold !px-6 !py-2.5 text-xs">
          حفظ كل الإعدادات
        </button>
      </div>
    </div>
  );
}
