"use client";

import { useState } from "react";
import type { Category, NewProduct } from "@/lib/types";
import { Field, ImagePicker, TextAreaField, TextField, Toggle } from "./Fields";

export function ProductForm({
  initial,
  categories,
  onSubmit,
  onCancel,
}: {
  initial: NewProduct;
  categories: Category[];
  onSubmit: (values: NewProduct) => void;
  onCancel: () => void;
}) {
  const [draft, setDraft] = useState<NewProduct>(initial);
  const [galleryText, setGalleryText] = useState(initial.gallery.join("\n"));
  const [featuresText, setFeaturesText] = useState(initial.features.join("\n"));
  const [error, setError] = useState("");

  const patch = (values: Partial<NewProduct>) => setDraft((current) => ({ ...current, ...values }));

  const submit = () => {
    if (draft.title.trim().length < 2) {
      setError("اسم المنتج مطلوب.");
      return;
    }
    if (!draft.image) {
      setError("اختر صورة للمنتج (رابط أو رفع).");
      return;
    }
    const gallery = galleryText
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean);
    const features = featuresText
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean);

    onSubmit({
      ...draft,
      title: draft.title.trim(),
      description: draft.description.trim(),
      gallery,
      features,
      price: Number.isFinite(draft.price) ? Math.max(0, draft.price) : 0,
      categoryId: draft.categoryId || categories[0]?.id || "kitchens",
    });
  };

  return (
    <div className="rounded-2xl border border-line bg-ink-850 p-5">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-sm font-extrabold text-cream">
          {initial.title ? `تعديل: ${initial.title}` : "إضافة منتج جديد"}
        </h3>
        <button
          type="button"
          onClick={onCancel}
          className="text-[11px] font-bold text-muted transition hover:text-cream"
        >
          إلغاء ✕
        </button>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <TextField
          label="اسم المنتج *"
          value={draft.title}
          onChange={(value) => patch({ title: value })}
          placeholder="مثال: مطبخ مينيمال أسود وخشب الجوز"
        />

        <Field label="الفئة">
          <select
            value={draft.categoryId}
            onChange={(event) => patch({ categoryId: event.target.value })}
            className="field"
          >
            {categories.map((category) => (
              <option key={category.id} value={category.id}>
                {category.name}
              </option>
            ))}
          </select>
        </Field>

        <TextField
          label="السعر (دج)"
          type="number"
          value={draft.price}
          onChange={(value) => patch({ price: Number(value) || 0 })}
          hint="اتركه 0 إذا كان السعر عند الطلب"
        />

        <div className="flex flex-col justify-end gap-2">
          <Toggle
            label="السعر عند الطلب (لا يظهر الرقم)"
            checked={draft.priceOnRequest}
            onChange={(value) => patch({ priceOnRequest: value })}
          />
          <Toggle
            label="منتج مميز (وسم مميز في المعرض)"
            checked={draft.featured}
            onChange={(value) => patch({ featured: value })}
          />
        </div>

        <div className="md:col-span-2">
          <TextAreaField
            label="الوصف"
            value={draft.description}
            onChange={(value) => patch({ description: value })}
            placeholder="اكتب تفاصيل المنتج: الخامات، التصميم، ما يميزه..."
            rows={3}
          />
        </div>

        <div className="md:col-span-2">
          <ImagePicker
            label="الصورة الرئيسية *"
            value={draft.image}
            onChange={(value) => patch({ image: value })}
            hint="يمكنك لصق رابط صورة خارجي أو رفع صورة من جهازك (تُحفظ داخل المتصفح)."
          />
        </div>

        <TextAreaField
          label="صور إضافية (رابط في كل سطر)"
          value={galleryText}
          onChange={setGalleryText}
          placeholder={"/images/kitchen-hero.jpg\nhttps://..."}
          rows={3}
        />

        <TextAreaField
          label="المميزات (ميزة في كل سطر)"
          value={featuresText}
          onChange={setFeaturesText}
          placeholder={"واجهات بدون مقابض\nإضاءة LED مدمجة"}
          rows={3}
        />
      </div>

      {error && (
        <p className="mt-3 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-[11px] font-semibold text-red-300">
          {error}
        </p>
      )}

      <div className="mt-5 flex gap-2">
        <button type="button" onClick={submit} className="btn-gold !px-6 !py-2.5 text-xs">
          حفظ المنتج
        </button>
        <button type="button" onClick={onCancel} className="btn-ghost !px-5 !py-2.5 text-xs">
          إلغاء
        </button>
      </div>
    </div>
  );
}
