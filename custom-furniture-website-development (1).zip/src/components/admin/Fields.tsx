"use client";

import { useRef, useState, type ReactNode } from "react";

export function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <label className="flex flex-col gap-1.5 text-[11px] font-bold text-cream/80">
      {label}
      {children}
      {hint && <span className="text-[10px] font-normal leading-4 text-muted">{hint}</span>}
    </label>
  );
}

export function TextField({
  label,
  value,
  onChange,
  placeholder,
  hint,
  type = "text",
  dir,
}: {
  label: string;
  value: string | number;
  onChange: (value: string) => void;
  placeholder?: string;
  hint?: string;
  type?: "text" | "number" | "url" | "email";
  dir?: "ltr" | "rtl";
}) {
  return (
    <Field label={label} hint={hint}>
      <input
        type={type}
        value={value}
        dir={dir}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
        className="field"
      />
    </Field>
  );
}

export function TextAreaField({
  label,
  value,
  onChange,
  placeholder,
  hint,
  rows = 4,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  hint?: string;
  rows?: number;
}) {
  return (
    <Field label={label} hint={hint}>
      <textarea
        value={value}
        rows={rows}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
        className="field resize-none"
      />
    </Field>
  );
}

export function Toggle({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <label className="flex cursor-pointer items-center gap-2.5 rounded-xl border border-line-soft bg-ink-950/50 px-3 py-2.5 text-[11px] font-bold text-cream/85">
      <input
        type="checkbox"
        checked={checked}
        onChange={(event) => onChange(event.target.checked)}
        className="h-4 w-4 accent-bronze-500"
      />
      {label}
    </label>
  );
}

export function ImagePicker({
  label,
  value,
  onChange,
  hint,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  hint?: string;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [error, setError] = useState("");

  const readFile = (file: File | undefined | null) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("الملف يجب أن يكون صورة.");
      return;
    }
    if (file.size > 1_400_000) {
      setError("حجم الصورة كبير (الحد 1.4MB). استخدم رابط صورة أو صورة أصغر.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        onChange(reader.result);
        setError("");
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="flex flex-col gap-2">
      <p className="text-[11px] font-bold text-cream/80">{label}</p>
      <div className="flex gap-3">
        <div className="h-20 w-24 shrink-0 overflow-hidden rounded-lg border border-line-soft bg-ink-950">
          {value ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={value} alt="معاينة" className="h-full w-full object-cover" />
          ) : (
            <span className="flex h-full items-center justify-center text-[10px] text-muted">بدون صورة</span>
          )}
        </div>
        <div className="flex flex-1 flex-col gap-2">
          <input
            type="url"
            dir="ltr"
            value={value.startsWith("data:") ? "" : value}
            onChange={(event) => onChange(event.target.value)}
            placeholder="/images/kitchen-hero.jpg أو https://..."
            className="field text-[11px]"
          />
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="rounded-lg border border-line-soft px-3 py-1.5 text-[10px] font-bold text-cream/80 transition hover:border-bronze-500"
            >
              رفع صورة من الجهاز
            </button>
            {value && (
              <button
                type="button"
                onClick={() => onChange("")}
                className="rounded-lg px-2 py-1.5 text-[10px] font-bold text-red-300/80 transition hover:text-red-300"
              >
                حذف
              </button>
            )}
          </div>
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(event) => readFile(event.target.files?.[0])}
          />
        </div>
      </div>
      {hint && <p className="text-[10px] text-muted">{hint}</p>}
      {error && <p className="text-[10px] font-semibold text-red-300">{error}</p>}
    </div>
  );
}
