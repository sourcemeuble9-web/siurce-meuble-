"use client";

import { useRef, useState } from "react";
import { useSite } from "@/lib/store";
import type { SiteData } from "@/lib/types";

export function BackupTab() {
  const { data, replaceData, resetData, notify } = useSite();
  const fileRef = useRef<HTMLInputElement>(null);
  const [message, setMessage] = useState("");

  const exportData = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `source-meuble-backup-${new Date().toISOString().slice(0, 10)}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
    setMessage("تم تنزيل نسخة احتياطية من المحتوى.");
  };

  const importData = async (file: File | undefined | null) => {
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as SiteData;
      replaceData(parsed);
      setMessage("تم استيراد البيانات بنجاح.");
    } catch {
      setMessage("تعذر قراءة الملف. تأكد أنه ملف JSON صادر من هذه اللوحة.");
    }
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="rounded-2xl border border-line bg-ink-850 p-5">
        <h3 className="text-sm font-extrabold text-cream">التخزين المحلي (localStorage)</h3>
        <p className="mt-2 text-[11px] leading-6 text-muted">
          كل تعديلات المنتجات والإعدادات تُحفظ في متصفح هذا الجهاز تحت المفتاح{" "}
          <code className="rounded bg-ink-950 px-1.5 py-0.5 text-bronze-300">source-meuble:data:v1</code>.
          لظهور نفس المحتوى على أجهزة أخرى، صدّر نسخة احتياطية واستوردها هناك، أو اربط الموقع بقاعدة بيانات
          (الرسائل فقط محفوظة حالياً في قاعدة البيانات).
        </p>
        <div className="mt-4 grid gap-2 text-[11px] text-cream/80 sm:grid-cols-3">
          <div className="rounded-xl border border-line bg-ink-900 p-3">
            <p className="text-lg font-extrabold text-bronze-300">{data.products.length}</p>
            <p className="text-[10px] text-muted">منتج محفوظ</p>
          </div>
          <div className="rounded-xl border border-line bg-ink-900 p-3">
            <p className="text-lg font-extrabold text-bronze-300">{data.categories.length}</p>
            <p className="text-[10px] text-muted">فئة</p>
          </div>
          <div className="rounded-xl border border-line bg-ink-900 p-3">
            <p className="text-lg font-extrabold text-bronze-300" dir="ltr">
              {data.settings.phone}
            </p>
            <p className="text-[10px] text-muted">رقم التواصل الحالي</p>
          </div>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        <button type="button" onClick={exportData} className="btn-ghost !py-3 text-xs">
          ⬇ تصدير نسخة احتياطية
        </button>
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          className="btn-ghost !py-3 text-xs"
        >
          ⬆ استيراد نسخة
        </button>
        <button
          type="button"
          onClick={() => {
            if (window.confirm("سيتم استرجاع المحتوى الافتراضي وحذف تعديلاتك المحلية. متابعة؟")) {
              resetData();
              notify("تمت استعادة المحتوى الافتراضي");
              setMessage("تمت استعادة المحتوى الافتراضي.");
            }
          }}
          className="rounded-full border border-red-500/30 px-4 py-3 text-xs font-bold text-red-300 transition hover:bg-red-500/10"
        >
          ↺ استعادة الافتراضي
        </button>
      </div>

      <input
        ref={fileRef}
        type="file"
        accept="application/json"
        className="hidden"
        onChange={(event) => void importData(event.target.files?.[0])}
      />

      {message && (
        <p className="rounded-xl border border-bronze-500/30 bg-bronze-500/10 px-4 py-3 text-[11px] font-semibold text-bronze-300">
          {message}
        </p>
      )}
    </div>
  );
}
