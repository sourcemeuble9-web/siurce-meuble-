"use client";

import { useSite } from "@/lib/store";
import { toTelLink, toWhatsAppLink } from "@/lib/format";
import { Reveal } from "./Reveal";
import { WhatsAppIcon } from "./Navbar";

export function Hero() {
  const { data } = useSite();
  const { settings } = data;

  return (
    <section id="top" className="grain relative overflow-hidden pt-[72px]">
      <div
        className="pointer-events-none absolute inset-0 opacity-70"
        style={{
          background:
            "radial-gradient(1100px 520px at 15% 0%, rgba(185,139,94,0.18), transparent 62%), radial-gradient(900px 500px at 90% 20%, rgba(201,154,63,0.12), transparent 60%)",
        }}
      />
      <div className="shell relative grid items-center gap-14 pb-20 pt-14 lg:grid-cols-[1.05fr_0.95fr] lg:pb-28 lg:pt-20">
        <Reveal className="relative z-10">
          <span className="inline-flex items-center gap-2 rounded-full border border-bronze-500/35 bg-bronze-500/10 px-4 py-1.5 text-[11px] font-bold tracking-wide text-bronze-300 sm:text-xs">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-bronze-400 opacity-75" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-bronze-400" />
            </span>
            {settings.heroBadge}
          </span>

          <h1 className="mt-6 text-balance text-[clamp(2.3rem,6vw,4.4rem)] font-extrabold leading-[1.08] text-cream">
            {settings.heroTitle}
            <span className="mt-2 block gold-text">{settings.heroHighlight}</span>
          </h1>

          <p className="mt-6 max-w-xl text-balance text-sm leading-8 text-muted sm:text-base">
            {settings.heroSubtitle}
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <a
              href={toWhatsAppLink(
                settings.whatsapp,
                "مرحباً Source Meuble، أريد تصور 3D ومخطط 2D لمشروعي",
              )}
              target="_blank"
              rel="noreferrer"
              className="btn-gold"
            >
              <WhatsAppIcon className="h-4 w-4" />
              اطلب تصميمك المجاني
            </a>
            <a href={toTelLink(settings.phone)} className="btn-ghost" dir="ltr">
              {settings.phone}
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 5.5C3 4.4 4 3.5 5 3.5h2.2c.5 0 1 .3 1.1.8l.8 3c.1.4 0 .8-.3 1l-1.5 1.1a12.4 12.4 0 0 0 6.3 6.3l1.1-1.5c.2-.3.6-.4 1-.3l3 .8c.5.1.8.6.8 1.1V19c0 1.1-.9 2-2 2C10.6 21 3 13.4 3 6V5.5Z" />
              </svg>
            </a>
          </div>

          <div className="mt-10 grid max-w-lg grid-cols-3 gap-4 border-t border-line pt-6">
            {[
              { value: `${settings.yearsExperience}+`, label: "سنة خبرة" },
              { value: `${settings.projectsCount}+`, label: "مشروع منجز" },
              { value: `${settings.clientsCount}+`, label: "عميل سعيد" },
            ].map((stat) => (
              <div key={stat.label}>
                <p className="font-display text-3xl font-semibold text-bronze-300">{stat.value}</p>
                <p className="mt-1 text-[11px] font-semibold text-muted sm:text-xs">{stat.label}</p>
              </div>
            ))}
          </div>
        </Reveal>

        <Reveal delay={150} className="relative">
          <div className="relative mx-auto max-w-[520px]">
            <div className="absolute -inset-3 rounded-[28px] border border-bronze-500/25" />
            <div className="relative overflow-hidden rounded-[24px] border border-line bg-ink-800 shadow-[0_40px_90px_-40px_rgba(0,0,0,0.95)]">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={settings.heroImage}
                alt="مطبخ فاخر من Source Meuble"
                className="h-[340px] w-full object-cover sm:h-[460px] lg:h-[560px]"
              />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/10 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-5">
                <div>
                  <p className="font-display text-lg tracking-[0.18em] text-cream">SOURCE MEUBLE</p>
                  <p className="mt-1 text-[11px] text-muted">{settings.tagline}</p>
                </div>
                <span className="rounded-full border border-bronze-500/40 bg-ink-950/70 px-3 py-1.5 text-[10px] font-bold text-bronze-300">
                  تصميم 3D قبل التنفيذ
                </span>
              </div>
            </div>

            <div className="float-slow absolute -right-3 top-8 hidden rounded-2xl border border-bronze-500/30 bg-ink-900/95 px-4 py-3 shadow-xl sm:block">
              <p className="text-[10px] font-bold tracking-widest text-bronze-400">2D + 3D</p>
              <p className="mt-1 text-xs font-semibold text-cream">شاهد بيتك قبل التصنيع</p>
            </div>

            <div className="absolute -bottom-5 -left-3 hidden rounded-2xl border border-line bg-ink-900/95 px-4 py-3 shadow-xl sm:block">
              <p className="text-[10px] text-muted">خامات وإكسسوارات</p>
              <p className="mt-1 text-xs font-bold text-cream">جودة أوروبية · ضمان</p>
            </div>
          </div>
        </Reveal>
      </div>

      <div className="shell relative">
        <div className="flex flex-wrap items-center justify-center gap-x-8 gap-y-3 border-y border-line py-5 text-[11px] font-semibold tracking-wide text-muted sm:text-xs">
          <span>مطابخ بدون مقابض</span>
          <Dot />
          <span>دريسنج بأبواب زجاجية</span>
          <Dot />
          <span>مكاتب تنفيذية</span>
          <Dot />
          <span>إضاءة LED مدمجة</span>
          <Dot />
          <span>تفصيل 100% حسب المقاس</span>
        </div>
      </div>
    </section>
  );
}

function Dot() {
  return <span className="h-1 w-1 rounded-full bg-bronze-500/70" />;
}
