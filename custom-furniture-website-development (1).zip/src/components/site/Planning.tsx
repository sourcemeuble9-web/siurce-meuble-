"use client";

import { useState } from "react";
import { useSite } from "@/lib/store";
import { toWhatsAppLink } from "@/lib/format";
import { Reveal } from "./Reveal";
import { WhatsAppIcon } from "./Navbar";

function Blueprint() {
  return (
    <svg viewBox="0 0 420 320" className="h-full w-full" role="img" aria-label="مخطط 2D لمطبخ">
      <defs>
        <pattern id="plan-grid" width="20" height="20" patternUnits="userSpaceOnUse">
          <path d="M20 0H0v20" fill="none" stroke="#2b2521" strokeWidth="0.6" />
        </pattern>
      </defs>
      <rect width="420" height="320" fill="#0d0b0a" />
      <rect width="420" height="320" fill="url(#plan-grid)" opacity="0.9" />

      {/* walls */}
      <rect x="30" y="30" width="360" height="260" fill="none" stroke="#b98b5e" strokeWidth="4" />
      <rect x="30" y="30" width="360" height="260" fill="none" stroke="#efd8a4" strokeWidth="1" strokeDasharray="2 6" />

      {/* tall units */}
      <rect x="42" y="42" width="52" height="150" fill="#171413" stroke="#c99a3f" strokeWidth="1.5" />
      <rect x="42" y="42" width="52" height="50" fill="#211c19" stroke="#3a322b" />
      <rect x="42" y="92" width="52" height="50" fill="#211c19" stroke="#3a322b" />
      <rect x="42" y="142" width="52" height="50" fill="#211c19" stroke="#3a322b" />

      {/* back counter */}
      <rect x="120" y="42" width="210" height="56" fill="#171413" stroke="#c99a3f" strokeWidth="1.5" />
      <circle cx="170" cy="70" r="13" fill="none" stroke="#b98b5e" strokeWidth="1.2" />
      <circle cx="170" cy="70" r="6" fill="none" stroke="#8f6844" strokeWidth="1" />
      <rect x="215" y="56" width="56" height="28" fill="none" stroke="#8f6844" strokeWidth="1.2" />
      <rect x="292" y="58" width="26" height="24" fill="none" stroke="#8f6844" strokeWidth="1.2" />

      {/* island */}
      <rect x="140" y="160" width="150" height="80" rx="4" fill="#1c1714" stroke="#efd8a4" strokeWidth="2" />
      <path d="M140 182h150" stroke="#8f6844" strokeWidth="1" strokeDasharray="3 4" />
      <circle cx="265" cy="200" r="4" fill="#c99a3f" />
      <circle cx="265" cy="220" r="4" fill="#c99a3f" />

      {/* stools */}
      <circle cx="170" cy="262" r="12" fill="none" stroke="#b98b5e" strokeWidth="1.2" />
      <circle cx="215" cy="262" r="12" fill="none" stroke="#b98b5e" strokeWidth="1.2" />
      <circle cx="260" cy="262" r="12" fill="none" stroke="#b98b5e" strokeWidth="1.2" />

      {/* sink cabinet */}
      <rect x="330" y="120" width="48" height="120" fill="#171413" stroke="#c99a3f" strokeWidth="1.5" />
      <rect x="343" y="150" width="22" height="18" rx="2" fill="none" stroke="#8f6844" strokeWidth="1.2" />

      {/* dimensions */}
      <path d="M30 300h360" stroke="#a99c8c" strokeWidth="0.9" />
      <path d="M30 294v12M390 294v12" stroke="#a99c8c" strokeWidth="0.9" />
      <path d="M406 30v260" stroke="#a99c8c" strokeWidth="0.9" />
      <path d="M400 30h12M400 290h12" stroke="#a99c8c" strokeWidth="0.9" />

      <g fill="#a99c8c" fontSize="9" fontFamily="sans-serif" textAnchor="middle">
        <text x="210" y="313">4.20 m</text>
        <text x="406" y="164" transform="rotate(90 406 164)">3.00 m</text>
        <text x="258" y="206" fill="#efd8a4">ISLAND</text>
        <text x="80" y="126" fill="#efd8a4" transform="rotate(90 80 126)">TALL UNITS</text>
        <text x="225" y="82" fill="#a99c8c">PLAN 2D — CUISINE</text>
      </g>
    </svg>
  );
}

export function Planning() {
  const { data, setGalleryFilter } = useSite();
  const [mode, setMode] = useState<"2d" | "3d">("2d");
  const { settings } = data;
  const previewImage =
    data.products.find((p) => p.categoryId === "kitchens")?.image ?? settings.heroImage;

  return (
    <section id="planning" className="relative scroll-mt-20 overflow-hidden border-t border-line bg-ink-950 py-20 sm:py-24">
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(700px 340px at 80% 10%, rgba(201,154,63,0.16), transparent 65%), radial-gradient(600px 320px at 5% 80%, rgba(185,139,94,0.1), transparent 65%)",
        }}
      />
      <div className="shell relative grid items-center gap-12 lg:grid-cols-2">
        <Reveal>
          <div className="relative rounded-3xl border border-bronze-500/25 bg-ink-900 p-2.5 shadow-[0_40px_100px_-50px_rgba(201,154,63,0.4)]">
            <div className="flex items-center justify-between px-3 py-2.5">
              <div className="flex gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-[#3a322b]" />
                <span className="h-2.5 w-2.5 rounded-full bg-[#3a322b]" />
                <span className="h-2.5 w-2.5 rounded-full bg-bronze-500/70" />
              </div>
              <span className="font-display text-[10px] tracking-[0.24em] text-muted">
                SOURCE MEUBLE · STUDIO
              </span>
            </div>

            <div className="relative overflow-hidden rounded-2xl border border-line">
              {mode === "2d" ? (
                <div className="aspect-[4/3] w-full">
                  <Blueprint />
                </div>
              ) : (
                <div className="relative aspect-[4/3] w-full">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={previewImage} alt="تصور 3D للمطبخ" className="h-full w-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink-950/70 to-transparent" />
                  <span className="absolute bottom-3 right-3 rounded-full bg-ink-950/80 px-3 py-1 text-[10px] font-bold text-bronze-300 backdrop-blur">
                    تصور 3D واقعي
                  </span>
                </div>
              )}

              <div className="absolute left-3 top-3 flex rounded-full border border-line-soft bg-ink-950/85 p-1 backdrop-blur">
                {(["2d", "3d"] as const).map((value) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setMode(value)}
                    className={`rounded-full px-3 py-1 text-[10px] font-extrabold uppercase transition ${
                      mode === value ? "bg-bronze-500 text-ink-950" : "text-muted"
                    }`}
                  >
                    {value}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-3">
              <p className="text-[11px] text-muted">
                {mode === "2d" ? "مخطط تنفيذي بمقاسات دقيقة" : "محاكاة الخامات والإضاءة قبل التصنيع"}
              </p>
              <button
                type="button"
                onClick={() => {
                  setGalleryFilter("kitchens");
                  document.getElementById("gallery")?.scrollIntoView({ behavior: "smooth" });
                }}
                className="text-[11px] font-bold text-bronze-300 hover:underline"
              >
                شاهد مطابخ منفذة ←
              </button>
            </div>
          </div>
        </Reveal>

        <Reveal delay={120}>
          <span className="eyebrow">Design first</span>
          <h2 className="mt-3 text-3xl font-extrabold leading-snug text-cream sm:text-4xl">
            {settings.planningTitle}
          </h2>
          <p className="mt-4 text-sm leading-8 text-muted">{settings.planningSubtitle}</p>

          <ul className="mt-7 space-y-3">
            {settings.planningPoints.map((point, index) => (
              <li key={point} className="flex items-start gap-3">
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-bronze-500/40 bg-bronze-500/10 font-display text-[11px] font-bold text-bronze-300">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <span className="text-sm leading-7 text-cream/85">{point}</span>
              </li>
            ))}
          </ul>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <a
              href={toWhatsAppLink(
                settings.whatsapp,
                "مرحباً Source Meuble، أريد الحصول على مخطط 2D وتصور 3D لمشروعي",
              )}
              target="_blank"
              rel="noreferrer"
              className="btn-gold"
            >
              <WhatsAppIcon className="h-4 w-4" />
              احصل على مخطط 2D/3D
            </a>
            <span className="text-[11px] font-semibold text-muted">مجاناً عند تأكيد المشروع</span>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
