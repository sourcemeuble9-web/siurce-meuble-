"use client";

import { useSite } from "@/lib/store";
import { Reveal } from "./Reveal";

const STEPS = [
  {
    title: "الاستماع والمعاينة",
    text: "نتحدث عن احتياجك، نزور الموقع ونرفع المقاسات بدقة مجاناً.",
    tag: "02 ساعة",
  },
  {
    title: "المخطط 2D",
    text: "توزيع وظيفي للخزائن والأجهزة والأدراج بمقاسات تنفيذية واضحة.",
    tag: "2-3 أيام",
  },
  {
    title: "التصور 3D",
    text: "صور واقعية للخامات والإضاءة حتى ترى النتيجة قبل التصنيع.",
    tag: "3-5 أيام",
  },
  {
    title: "التصنيع والتركيب",
    text: "تصنيع في ورشتنا، تسليم في الموعد وتركيب نظيف مع ضمان.",
    tag: "2-4 أسابيع",
  },
];

export function Process() {
  const { data } = useSite();

  return (
    <section id="process" className="scroll-mt-20 border-t border-line bg-ink-900 py-20 sm:py-24">
      <div className="shell">
        <Reveal className="max-w-2xl">
          <span className="eyebrow">How it works</span>
          <h2 className="mt-3 text-3xl font-extrabold text-cream sm:text-4xl">
            من الفكرة إلى التركيب في <span className="gold-text">4 مراحل</span>
          </h2>
          <p className="mt-4 text-sm leading-8 text-muted">
            وضوح كامل في كل خطوة، بدون مفاجآت في السعر أو الموعد. أنت توافق على المخطط والتصور قبل بدء التصنيع.
          </p>
        </Reveal>

        <div className="relative mt-12">
          <div className="absolute inset-x-0 top-[38px] hidden h-px bg-gradient-to-l from-transparent via-line-soft to-transparent lg:block" />
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((step, index) => (
              <Reveal key={step.title} delay={index * 100}>
                <div className="group relative h-full rounded-2xl border border-line bg-ink-850 p-6 transition hover:border-bronze-500/40">
                  <div className="flex items-center justify-between">
                    <span className="flex h-12 w-12 items-center justify-center rounded-full border border-bronze-500/35 bg-ink-950 font-display text-lg font-semibold text-bronze-300">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    <span className="rounded-full border border-line-soft px-2.5 py-1 text-[10px] font-bold text-muted">
                      {step.tag}
                    </span>
                  </div>
                  <h3 className="mt-5 text-base font-extrabold text-cream">{step.title}</h3>
                  <p className="mt-2 text-xs leading-7 text-muted">{step.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>

        <Reveal delay={140} className="mt-10 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 rounded-2xl border border-line bg-ink-850 px-6 py-5 text-center text-xs font-semibold text-muted">
          <span>✓ معاينة مجانية</span>
          <span>✓ مخطط وتصور 3D قبل الدفع</span>
          <span>✓ ضمان على التصنيع والتركيب</span>
          <span>✓ فريق {data.settings.companyName} الخاص</span>
        </Reveal>
      </div>
    </section>
  );
}
