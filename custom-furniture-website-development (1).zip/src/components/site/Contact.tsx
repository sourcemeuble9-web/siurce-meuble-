"use client";

import { useActionState } from "react";
import { useSite } from "@/lib/store";
import { submitContactMessage, type ContactState } from "@/lib/message-actions";
import { toTelLink, toWhatsAppLink } from "@/lib/format";
import { Reveal } from "./Reveal";
import { WhatsAppIcon } from "./Navbar";

const initialState: ContactState = { status: "idle" };

export function Contact() {
  const { data } = useSite();
  const { settings } = data;
  const [state, formAction, pending] = useActionState(submitContactMessage, initialState);

  return (
    <section id="contact" className="scroll-mt-20 border-t border-line bg-ink-900 py-20 sm:py-24">
      <div className="shell">
        <Reveal className="max-w-2xl">
          <span className="eyebrow">Let&apos;s talk</span>
          <h2 className="mt-3 text-3xl font-extrabold text-cream sm:text-4xl">
            مشروعك يبدأ <span className="gold-text">بمكالمة</span>
          </h2>
          <p className="mt-4 text-sm leading-8 text-muted">
            أخبرنا عن المساحة التي تريد تجهيزها، ونحن نتولى المعاينة والمخطط والتصور ثلاثي الأبعاد ثم التصنيع والتركيب.
          </p>
        </Reveal>

        <div className="mt-10 grid gap-6 lg:grid-cols-[0.85fr_1.15fr]">
          <div className="flex flex-col gap-4">
            <a
              href={toTelLink(settings.phone)}
              className="group flex items-center gap-4 rounded-2xl border border-line bg-ink-850 p-5 transition hover:border-bronze-500/50"
            >
              <span className="flex h-12 w-12 items-center justify-center rounded-full border border-bronze-500/30 bg-bronze-500/10 text-bronze-300">
                <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.7">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M3 5.5C3 4.4 4 3.5 5 3.5h2.2c.5 0 1 .3 1.1.8l.8 3c.1.4 0 .8-.3 1l-1.5 1.1a12.4 12.4 0 0 0 6.3 6.3l1.1-1.5c.2-.3.6-.4 1-.3l3 .8c.5.1.8.6.8 1.1V19c0 1.1-.9 2-2 2C10.6 21 3 13.4 3 6V5.5Z"
                  />
                </svg>
              </span>
              <div>
                <p className="text-[11px] text-muted">اتصل بنا مباشرة</p>
                <p className="text-lg font-extrabold text-cream" dir="ltr">
                  {settings.phone}
                </p>
              </div>
            </a>

            <a
              href={toWhatsAppLink(settings.whatsapp, "مرحباً Source Meuble، أريد مناقشة مشروع أثاث")}
              target="_blank"
              rel="noreferrer"
              className="group flex items-center gap-4 rounded-2xl border border-line bg-ink-850 p-5 transition hover:border-[#25D366]/50"
            >
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-[#25D366]/15 text-[#25D366]">
                <WhatsAppIcon className="h-5 w-5" />
              </span>
              <div>
                <p className="text-[11px] text-muted">واتساب — أسرع رد</p>
                <p className="text-base font-extrabold text-cream">أرسل صور ومقاسات مساحتك</p>
              </div>
            </a>

            <div className="overflow-hidden rounded-2xl border border-line bg-ink-850">
              <div className="relative h-40 overflow-hidden bg-ink-800">
                <div
                  className="absolute inset-0 opacity-60"
                  style={{
                    backgroundImage:
                      "linear-gradient(#2b2521 1px, transparent 1px), linear-gradient(90deg, #2b2521 1px, transparent 1px)",
                    backgroundSize: "28px 28px",
                  }}
                />
                <div
                  className="absolute inset-0"
                  style={{
                    background:
                      "radial-gradient(220px 140px at 55% 50%, rgba(201,154,63,0.22), transparent 70%)",
                  }}
                />
                <svg viewBox="0 0 300 160" className="absolute inset-0 h-full w-full">
                  <path d="M0 118 L70 92 L118 104 L176 60 L236 76 L300 44" fill="none" stroke="#3a322b" strokeWidth="6" />
                  <path d="M40 160 L52 108 L120 96 L150 40 L210 60 L250 0" fill="none" stroke="#2b2521" strokeWidth="10" />
                  <circle cx="176" cy="70" r="26" fill="rgba(201,154,63,0.12)" />
                  <circle cx="176" cy="70" r="5" fill="#dcb970" />
                </svg>
                <span className="absolute bottom-3 right-3 rounded-full border border-line-soft bg-ink-950/80 px-3 py-1 text-[10px] font-bold text-bronze-300">
                  {settings.address}
                </span>
              </div>
              <div className="flex items-center justify-between gap-3 p-4">
                <div>
                  <p className="text-[11px] text-muted">موقعنا على خرائط Google</p>
                  <p className="mt-0.5 text-sm font-bold text-cream">افتح الاتجاهات في تطبيقك</p>
                </div>
                <a
                  href={settings.mapUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-full border border-bronze-500/40 px-4 py-2 text-xs font-bold text-bronze-300 transition hover:bg-bronze-500 hover:text-ink-950"
                >
                  خرائط Google ↗
                </a>
              </div>
            </div>
          </div>

          <form action={formAction} className="rounded-2xl border border-line bg-ink-850 p-6 sm:p-8">
            <h3 className="font-display text-xl tracking-wide text-cream">طلب معاينة وتصميم</h3>
            <p className="mt-1 text-xs text-muted">اترك معلوماتك وسنتواصل معك خلال 24 ساعة.</p>

            <div className="mt-6 grid gap-3.5 sm:grid-cols-2">
              <label className="flex flex-col gap-1.5 text-[11px] font-bold text-cream/80">
                الاسم الكامل *
                <input name="name" required className="field" placeholder="اسمك" />
              </label>
              <label className="flex flex-col gap-1.5 text-[11px] font-bold text-cream/80">
                رقم الهاتف *
                <input name="phone" required dir="ltr" className="field text-right" placeholder="05XXXXXXXX" />
              </label>
              <label className="flex flex-col gap-1.5 text-[11px] font-bold text-cream/80 sm:col-span-2">
                نوع المشروع
                <select name="projectType" className="field">
                  {data.categories.map((category) => (
                    <option key={category.id} value={category.name}>
                      {category.name}
                    </option>
                  ))}
                  <option value="مشروع آخر">مشروع آخر</option>
                </select>
              </label>
              <label className="flex flex-col gap-1.5 text-[11px] font-bold text-cream/80 sm:col-span-2">
                تفاصيل الطلب *
                <textarea
                  name="content"
                  required
                  rows={4}
                  className="field resize-none"
                  placeholder="المدينة والحي، المساحة التقريبية، الألوان أو الصور التي تحبها..."
                />
              </label>
            </div>

            <button type="submit" disabled={pending} className="btn-gold mt-5 w-full disabled:opacity-60">
              {pending ? "جاري الإرسال..." : "أرسل الطلب"}
              <svg viewBox="0 0 20 20" className="h-4 w-4" fill="currentColor">
                <path d="M18 3 2 9.3l5.4 1.8L15 5.5 8.6 12.3l-.4 4.9 2.6-3.2 4.4 3z" />
              </svg>
            </button>

            {state.status !== "idle" && (
              <p
                className={`mt-4 rounded-xl border px-4 py-3 text-xs font-semibold ${
                  state.status === "success"
                    ? "border-green-500/30 bg-green-500/10 text-green-300"
                    : "border-red-500/30 bg-red-500/10 text-red-300"
                }`}
              >
                {state.message}
              </p>
            )}

            <p className="mt-3 text-[10px] leading-5 text-muted">
              أو تواصل مباشرة على واتساب{" "}
              <a
                href={toWhatsAppLink(settings.whatsapp)}
                target="_blank"
                rel="noreferrer"
                className="font-bold text-bronze-300 hover:underline"
                dir="ltr"
              >
                {settings.phone}
              </a>
            </p>
          </form>
        </div>
      </div>
    </section>
  );
}
