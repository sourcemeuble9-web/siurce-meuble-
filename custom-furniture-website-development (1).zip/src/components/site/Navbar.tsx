"use client";

import { useEffect, useState } from "react";
import { Logo } from "./Logo";
import { useSite } from "@/lib/store";
import { toTelLink, toWhatsAppLink } from "@/lib/format";

const LINKS = [
  { href: "#services", label: "خدماتنا" },
  { href: "#gallery", label: "المعرض" },
  { href: "#planning", label: "تصميم 2D / 3D" },
  { href: "#process", label: "مراحل العمل" },
  { href: "#about", label: "من نحن" },
  { href: "#contact", label: "تواصل معنا" },
];

export function Navbar() {
  const { data, openAdmin } = useSite();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-40 transition-all duration-300 ${
        scrolled
          ? "border-b border-line bg-ink-950/90 backdrop-blur-xl"
          : "border-b border-transparent bg-gradient-to-b from-ink-950/80 to-transparent"
      }`}
    >
      <div className="shell flex h-[72px] items-center justify-between gap-4">
        <a href="#top" aria-label="Source Meuble" className="shrink-0">
          <Logo compact />
        </a>

        <nav className="hidden items-center gap-7 lg:flex">
          {LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="group relative text-[13px] font-semibold text-muted transition hover:text-cream"
            >
              {link.label}
              <span className="absolute -bottom-1.5 right-0 h-px w-0 bg-bronze-400 transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <a
            href={toTelLink(data.settings.phone)}
            className="hidden items-center gap-2 rounded-full border border-line-soft px-3.5 py-2 text-xs font-bold text-cream transition hover:border-bronze-500 sm:flex"
            dir="ltr"
          >
            <PhoneIcon className="h-3.5 w-3.5 text-bronze-400" />
            {data.settings.phone}
          </a>
          <a
            href={toWhatsAppLink(data.settings.whatsapp, "مرحباً Source Meuble، أريد طلب تصميم أثاث")}
            target="_blank"
            rel="noreferrer"
            className="btn-gold hidden !px-4 !py-2.5 text-xs sm:inline-flex"
          >
            <WhatsAppIcon className="h-4 w-4" />
            واتساب
          </a>
          <button
            type="button"
            onClick={openAdmin}
            aria-label="لوحة التحكم"
            title="لوحة التحكم"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-line-soft text-muted transition hover:border-bronze-500 hover:text-bronze-400"
          >
            <GearIcon className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-label="القائمة"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-line-soft text-cream lg:hidden"
          >
            {open ? <CloseIcon className="h-4 w-4" /> : <MenuIcon className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-line bg-ink-950/98 px-5 pb-6 pt-3 lg:hidden">
          <nav className="flex flex-col">
            {LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className="border-b border-line/60 py-3 text-sm font-semibold text-cream/90"
              >
                {link.label}
              </a>
            ))}
          </nav>
          <div className="mt-4 grid grid-cols-2 gap-2">
            <a href={toTelLink(data.settings.phone)} className="btn-ghost !py-2.5 text-xs">
              <PhoneIcon className="h-4 w-4" /> اتصل
            </a>
            <a
              href={toWhatsAppLink(data.settings.whatsapp, "مرحباً Source Meuble")}
              target="_blank"
              rel="noreferrer"
              className="btn-gold !py-2.5 text-xs"
            >
              <WhatsAppIcon className="h-4 w-4" /> واتساب
            </a>
          </div>
        </div>
      )}
    </header>
  );
}

function PhoneIcon({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.8">
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        d="M3 5.5C3 4.4 3.9 3.5 5 3.5h2.2c.5 0 .9.3 1 .8l.9 3c.1.4 0 .8-.4 1l-1.5 1a12.5 12.5 0 0 0 6.5 6.5l1-1.5c.2-.4.6-.5 1-.4l3 .9c.5.1.8.5.8 1V19c0 1.1-.9 2-2 2h-.5C10.4 21 3 13.6 3 5.5Z"
      />
    </svg>
  );
}

export function WhatsAppIcon({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} fill="currentColor">
      <path d="M16 3C9.4 3 4 8.4 4 15c0 2.4.7 4.6 1.9 6.5L4 29l7.7-1.8c1.3.7 2.8 1.1 4.3 1.1 6.6 0 12-5.4 12-12S22.6 3 16 3Zm0 21.8c-1.8 0-3.5-.5-5-1.4l-.4-.2-4.6 1.1 1.1-4.5-.2-.4A9.7 9.7 0 1 1 25.8 15c0 5.4-4.4 9.8-9.8 9.8Zm5.4-7.3c-.3-.1-1.8-.9-2.1-1-.3-.1-.5-.1-.7.1-.2.3-.8 1-.9 1.2-.2.2-.3.2-.6.1-.3-.1-1.3-.5-2.4-1.5-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.6l.5-.5c.1-.2.2-.3.3-.5.1-.2 0-.4 0-.5 0-.2-.7-1.6-.9-2.2-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.5s1 2.9 1.2 3.1c.1.2 2 3.2 5 4.5.7.3 1.3.5 1.7.6.7.2 1.4.2 1.9.1.6-.1 1.8-.7 2-1.4.2-.7.2-1.3.2-1.4-.1-.1-.3-.2-.6-.3Z" />
    </svg>
  );
}

function MenuIcon({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2">
      <path strokeLinecap="round" d="M4 7h16M4 12h16M4 17h16" />
    </svg>
  );
}

function CloseIcon({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2">
      <path strokeLinecap="round" d="M6 6l12 12M18 6L6 18" />
    </svg>
  );
}

function GearIcon({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.7">
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.6-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.6V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.6 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z" />
    </svg>
  );
}
