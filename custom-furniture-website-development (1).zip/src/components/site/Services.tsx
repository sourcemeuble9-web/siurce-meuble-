"use client";

import { useSite } from "@/lib/store";
import { Reveal } from "./Reveal";

function CategoryIcon({ id, className = "" }: { id: string; className?: string }) {
  if (id === "dressing") {
    return (
      <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.5">
        <rect x="3" y="3" width="18" height="18" rx="1.5" />
        <path d="M12 3v18M3 12h18" />
        <path d="M7 7l1.5 1M17 7l-1.5 1M7 17l1.5-1M17 17l-1.5-1" strokeLinecap="round" />
      </svg>
    );
  }
  if (id === "offices") {
    return (
      <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M3 7h18M3 7v13h18V7" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M7 7V3.5h10V7M8 7v13M16 7v13M8 12h8" strokeLinecap="round" />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M3 10h18M3 10v9h18v-9" strokeLinecap="round" />
      <path d="M5 10V5h6v5M14 10V5h5v5" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M9 14h2M13 14h2M3 19v2M21 19v2" strokeLinecap="round" />
    </svg>
  );
}

export function Services() {
  const { data, setGalleryFilter } = useSite();

  const explore = (categoryId: string) => {
    setGalleryFilter(categoryId);
    document.getElementById("gallery")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <section id="services" className="relative scroll-mt-20 border-t border-line bg-ink-950 py-20 sm:py-24">
      <div className="shell">
        <Reveal className="max-w-2xl">
          <span className="eyebrow">What we craft</span>
          <h2 className="mt-3 text-3xl font-extrabold text-cream sm:text-4xl">
            نصنع ثلاث عائلات من الأثاث، <span className="gold-text">بكل تفاصيلها</span>
          </h2>
          <p className="mt-4 text-sm leading-8 text-muted">
            كل قطعة تبدأ من مقاس غرفتك وخيالك، وتنتهي بتركيب نظيف في بيتك. اختر العائلة التي تهمك لاستكشاف أعمالنا.
          </p>
        </Reveal>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {data.categories.map((category, index) => {
            const count = data.products.filter((p) => p.categoryId === category.id).length;
            return (
              <Reveal key={category.id} delay={index * 110} as="article">
                <button
                  type="button"
                  onClick={() => explore(category.id)}
                  className="group relative block h-[420px] w-full overflow-hidden rounded-2xl border border-line text-right"
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={category.image}
                    alt={category.name}
                    className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-[1.07]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/55 to-ink-950/10 transition group-hover:from-ink-950 group-hover:via-ink-950/40" />
                  <div className="absolute inset-x-0 top-0 flex items-center justify-between p-5">
                    <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-bronze-500/40 bg-ink-950/70 text-bronze-300 backdrop-blur">
                      <CategoryIcon id={category.id} className="h-5 w-5" />
                    </span>
                    <span className="rounded-full border border-line-soft bg-ink-950/70 px-3 py-1 text-[10px] font-bold text-muted backdrop-blur">
                      {count} أعمال
                    </span>
                  </div>
                  <div className="absolute inset-x-0 bottom-0 p-5">
                    <p className="font-display text-xs tracking-[0.24em] text-bronze-400">
                      {category.englishName.toUpperCase()}
                    </p>
                    <h3 className="mt-1.5 text-xl font-extrabold text-cream">{category.name}</h3>
                    <p className="mt-1.5 text-xs leading-6 text-muted">{category.tagline}</p>
                    <span className="mt-4 inline-flex items-center gap-2 text-xs font-bold text-bronze-300">
                      استكشف الأعمال
                      <svg viewBox="0 0 20 20" className="h-4 w-4 transition group-hover:-translate-x-1" fill="currentColor">
                        <path d="M12.3 4.3 6.6 10l5.7 5.7 1.4-1.4L9.4 10l4.3-4.3z" />
                      </svg>
                    </span>
                  </div>
                </button>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
