"use client";

import { useSite } from "@/lib/store";
import { priceLabel, toTelLink, toWhatsAppLink } from "@/lib/format";
import { Reveal } from "./Reveal";
import { WhatsAppIcon } from "./Navbar";

export function Gallery() {
  const { data, galleryFilter, setGalleryFilter, activeProduct, openProduct, closeProduct } = useSite();

  const filters = [
    { id: "all", label: "كل الأعمال" },
    ...data.categories.map((c) => ({ id: c.id, label: c.name })),
  ];

  const products =
    galleryFilter === "all"
      ? data.products
      : data.products.filter((p) => p.categoryId === galleryFilter);

  const categoryName = (id: string) => data.categories.find((c) => c.id === id)?.name ?? "";
  const categoryEnglish = (id: string) =>
    data.categories.find((c) => c.id === id)?.englishName ?? "";

  return (
    <section id="gallery" className="relative scroll-mt-20 border-t border-line bg-ink-900 py-20 sm:py-24">
      <div className="shell">
        <Reveal className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
          <div className="max-w-xl">
            <span className="eyebrow">Our portfolio</span>
            <h2 className="mt-3 text-3xl font-extrabold text-cream sm:text-4xl">
              معرض <span className="gold-text">أعمالنا</span>
            </h2>
            <p className="mt-4 text-sm leading-8 text-muted">
              مشاريع حقيقية صُممت ونُفذت حسب الطلب. اضغط على أي صورة لعرض التفاصيل والسعر وطلب نفس التصميم.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {filters.map((filter) => {
              const active = galleryFilter === filter.id;
              return (
                <button
                  key={filter.id}
                  type="button"
                  onClick={() => setGalleryFilter(filter.id)}
                  className={`rounded-full border px-4 py-2 text-xs font-bold transition ${
                    active
                      ? "border-transparent bg-gradient-to-l from-bronze-400 to-bronze-600 text-ink-950"
                      : "border-line-soft text-muted hover:border-bronze-500/60 hover:text-cream"
                  }`}
                >
                  {filter.label}
                </button>
              );
            })}
          </div>
        </Reveal>

        {products.length === 0 ? (
          <p className="mt-14 rounded-2xl border border-line bg-ink-850 p-10 text-center text-sm text-muted">
            لا توجد أعمال في هذه الفئة بعد. أضف أعمالك من لوحة التحكم.
          </p>
        ) : (
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {products.map((product, index) => (
              <Reveal key={product.id} delay={Math.min(index, 5) * 70}>
                <button
                  type="button"
                  onClick={() => openProduct(product)}
                  className="group relative block w-full overflow-hidden rounded-2xl border border-line bg-ink-850 text-right transition hover:border-bronze-500/50"
                >
                  <div className="relative aspect-[4/5] overflow-hidden">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={product.image}
                      alt={product.title}
                      loading="lazy"
                      className="h-full w-full object-cover transition duration-700 group-hover:scale-[1.06]"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-ink-950/95 via-ink-950/25 to-transparent" />
                    {product.featured && (
                      <span className="absolute right-3 top-3 rounded-full bg-bronze-500/95 px-2.5 py-1 text-[10px] font-extrabold text-ink-950">
                        مميز
                      </span>
                    )}
                    <span className="absolute left-3 top-3 rounded-full border border-line-soft bg-ink-950/75 px-2.5 py-1 text-[10px] font-bold text-bronze-300 backdrop-blur">
                      {categoryName(product.categoryId)}
                    </span>
                    <div className="absolute inset-x-0 bottom-0 p-4">
                      <p className="font-display text-[10px] tracking-[0.22em] text-bronze-400">
                        {categoryEnglish(product.categoryId).toUpperCase()}
                      </p>
                      <h3 className="mt-1 text-base font-extrabold leading-snug text-cream">
                        {product.title}
                      </h3>
                      <div className="mt-2 flex items-center justify-between">
                        <span className="text-xs font-bold text-bronze-300">
                          {priceLabel(product.price, product.priceOnRequest)}
                        </span>
                        <span className="flex h-8 w-8 items-center justify-center rounded-full border border-bronze-500/40 text-bronze-300 transition group-hover:bg-bronze-500 group-hover:text-ink-950">
                          <svg viewBox="0 0 20 20" className="h-3.5 w-3.5" fill="currentColor">
                            <path d="M7.7 4.3 6.3 5.7 10.6 10l-4.3 4.3 1.4 1.4L13.4 10z" />
                          </svg>
                        </span>
                      </div>
                    </div>
                  </div>
                </button>
              </Reveal>
            ))}
          </div>
        )}
      </div>

      {activeProduct && (
        <div
          className="fixed inset-0 z-[70] flex items-end justify-center bg-black/80 p-0 backdrop-blur-sm sm:items-center sm:p-6"
          role="dialog"
          aria-modal="true"
          onClick={closeProduct}
        >
          <div
            className="relative max-h-[92vh] w-full max-w-5xl overflow-y-auto rounded-t-3xl border border-line bg-ink-900 sm:rounded-3xl"
            onClick={(event) => event.stopPropagation()}
          >
            <button
              type="button"
              onClick={closeProduct}
              aria-label="إغلاق"
              className="absolute left-4 top-4 z-10 flex h-9 w-9 items-center justify-center rounded-full border border-line-soft bg-ink-950/80 text-cream backdrop-blur transition hover:border-bronze-500"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" d="M6 6l12 12M18 6L6 18" />
              </svg>
            </button>

            <div className="grid lg:grid-cols-2">
              <div className="relative bg-ink-800">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={activeProduct.image}
                  alt={activeProduct.title}
                  className="h-[280px] w-full object-cover sm:h-[380px] lg:h-full lg:min-h-[460px]"
                />
                {activeProduct.gallery.length > 1 && (
                  <div className="absolute inset-x-0 bottom-0 flex gap-2 bg-gradient-to-t from-ink-950/90 to-transparent p-3">
                    {activeProduct.gallery.slice(0, 4).map((img, i) => (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        key={`${img}-${i}`}
                        src={img}
                        alt=""
                        className="h-12 w-12 rounded-lg border border-white/15 object-cover"
                      />
                    ))}
                  </div>
                )}
              </div>

              <div className="flex flex-col p-6 sm:p-8">
                <span className="w-fit rounded-full border border-bronze-500/30 bg-bronze-500/10 px-3 py-1 text-[10px] font-bold text-bronze-300">
                  {categoryName(activeProduct.categoryId)}
                </span>
                <h3 className="mt-3 text-2xl font-extrabold text-cream">{activeProduct.title}</h3>
                <p className="mt-2 font-display text-lg text-bronze-300">
                  {priceLabel(activeProduct.price, activeProduct.priceOnRequest)}
                </p>
                <p className="mt-4 text-sm leading-8 text-muted">{activeProduct.description}</p>

                {activeProduct.features.length > 0 && (
                  <ul className="mt-5 grid gap-2.5 sm:grid-cols-2">
                    {activeProduct.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-2 text-xs leading-6 text-cream/85">
                        <svg viewBox="0 0 20 20" className="mt-0.5 h-4 w-4 shrink-0 text-bronze-400" fill="currentColor">
                          <path d="M8.2 13.9 4.6 10.3 3.2 11.7l5 5L18 6.9l-1.4-1.4z" />
                        </svg>
                        {feature}
                      </li>
                    ))}
                  </ul>
                )}

                <div className="mt-6 rounded-xl border border-line bg-ink-850 p-3 text-[11px] leading-6 text-muted">
                  المقاسات، الألوان والخامات قابلة للتعديل حسب مساحتك. سعر القطعة يشمل التصنيع والتركيب داخل الولاية.
                </div>

                <div className="mt-6 flex flex-wrap gap-2.5">
                  <a
                    href={toWhatsAppLink(
                      data.settings.whatsapp,
                      `مرحباً Source Meuble، أنا مهتم بـ "${activeProduct.title}" (${
                        activeProduct.priceOnRequest
                          ? "أريد معرفة السعر"
                          : priceLabel(activeProduct.price, false)
                      }). أريد مخططاً وتصوراً 3D.`,
                    )}
                    target="_blank"
                    rel="noreferrer"
                    className="btn-gold flex-1"
                  >
                    <WhatsAppIcon className="h-4 w-4" />
                    اطلب نفس التصميم
                  </a>
                  <a href={toTelLink(data.settings.phone)} className="btn-ghost">
                    اتصال
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
