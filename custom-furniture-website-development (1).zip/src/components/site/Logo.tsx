export function LogoMark({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="sm-gold" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
          <stop stopColor="#efd8a4" />
          <stop offset="0.55" stopColor="#c99a3f" />
          <stop offset="1" stopColor="#8f6844" />
        </linearGradient>
      </defs>
      <rect x="2.5" y="5" width="43" height="38" rx="4" stroke="url(#sm-gold)" strokeWidth="1.6" />
      <rect x="7" y="9.5" width="15" height="29" rx="1.2" fill="#221c19" stroke="url(#sm-gold)" strokeWidth="0.9" />
      <rect x="26" y="9.5" width="15" height="29" rx="1.2" fill="#221c19" stroke="url(#sm-gold)" strokeWidth="0.9" />
      <path d="M22 9.5v29M7 24h15M26 24h15" stroke="url(#sm-gold)" strokeWidth="0.8" opacity="0.55" />
      <circle cx="18.5" cy="24" r="1.7" fill="url(#sm-gold)" />
      <circle cx="29.5" cy="24" r="1.7" fill="url(#sm-gold)" />
      <rect x="13" y="33" width="4" height="1.1" rx="0.55" fill="url(#sm-gold)" />
      <rect x="31" y="33" width="4" height="1.1" rx="0.55" fill="url(#sm-gold)" />
    </svg>
  );
}

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <span className="inline-flex items-center gap-2.5">
      <LogoMark className={compact ? "h-8 w-8" : "h-10 w-10"} />
      <span className="flex flex-col leading-none">
        <span className="font-display text-xl font-semibold tracking-[0.14em] text-cream sm:text-2xl">
          SOURCE <span className="gold-text">MEUBLE</span>
        </span>
        <span className="mt-1 text-[9px] font-semibold tracking-[0.32em] text-muted sm:text-[10px]">
          ATELIER · SUR MESURE
        </span>
      </span>
    </span>
  );
}
