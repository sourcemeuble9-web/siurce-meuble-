"use client";

import { useSite } from "@/lib/store";
import { toWhatsAppLink } from "@/lib/format";
import { Reveal } from "./Reveal";
import { WhatsAppIcon } from "./Navbar";

const VALUES = [
  { title: "خامات مختارة", text: "ألواح مقاومة للرطوبة، خشب طبيعي وإكسسوارات هيدروليكية." },
  { title: "تفصيل حرفي", text: "ورشة خاصة وفريق تركيب دائم، لا نعتمد على وسطاء." },
  { title: "إضاءة مدمجة", text: "LED مخفية داخل الخزائن والأرفف بلمسة دافئة." },
  { title: "تسليم في الموعد", text: "جدول زمني واضح من التوقيع على المخطط إلى التركيب." },
];

export function About() {
  const { data } = useSite();
  const { settings } = data;

  return (
    <section id="about" className="scroll-mt-20 border-t border-line bg-ink-950 py-20 sm:py-24">
      <div className="shell grid items-center gap-12 lg:grid-cols-[0.95fr_1.05fr]">
        <Reveal>
          <div className="relative">
            <div className="overflow-hidden rounded-3xl border border-line">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={settings.aboutImage}
                alt={settings.aboutTitle}
                className="h-[340px] w-full object-cover sm:h-[440px]"
              />
            </div>
            <div className="absolute -bottom-6 right-5 rounded-2xl border border-bronze-500/30 bg-ink-900/95 px-5 py-4 shadow-2xl backdrop-blur">
              <p className="font-display text-3xl font-semibold text-bronze-300">{settings.yearsExperience}+</p>
              <p className="mt-1 text-[11px] font-semibold text-muted">سنة في النجارة الفاخرة</p>
            </div>
            <div className="absolute -top-4 left-4 hidden rounded-xl border border-line bg-ink-900/95 px-4 py-2 text-[10px] font-bold tracking-widest text-bronze-300 sm:block">
              ATELIER SOURCE MEUBLE
            </div>
          </div>
        </Reveal>

        <Reveal delay={120}>
          <span className="eyebrow">The atelier</span>
          <h2 className="mt-3 text-3xl font-extrabold leading-snug text-cream sm:text-4xl">
            {settings.aboutTitle}
          </h2>
          <p className="mt-4 text-sm leading-8 text-muted">{settings.aboutText}</p>

          <div className="mt-7 grid gap-4 sm:grid-cols-2">
            {VALUES.map((value) => (
              <div key={value.title} className="rounded-xl border border-line bg-ink-850 p-4">
                <div className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-bronze-400" />
                  <h3 className="text-sm font-bold text-cream">{value.title}</h3>
                </div>
                <p className="mt-1.5 text-[11px] leading-6 text-muted">{value.text}</p>
              </div>
            ))}
          </div>

          <div className="mt-7 flex flex-wrap items-center gap-3">
            <a
              href={toWhatsAppLink(settings.whatsapp, "مرحباً Source Meuble، أريد زيارة الورشة وحجز موعد")}
              target="_blank"
              rel="noreferrer"
              className="btn-gold"
            >
              <WhatsAppIcon className="h-4 w-4" />
              احجز زيارة للورشة
            </a>
            <a href="#gallery" className="btn-ghost">
              شاهد أعمالنا
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
