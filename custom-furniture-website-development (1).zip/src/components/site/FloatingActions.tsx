"use client";

import { useSite } from "@/lib/store";
import { toTelLink, toWhatsAppLink } from "@/lib/format";
import { WhatsAppIcon } from "./Navbar";

export function FloatingActions() {
  const { data, openAdmin } = useSite();
  const { settings } = data;

  return (
    <>
      <div className="fixed bottom-5 left-4 z-40 flex flex-col items-center gap-3 sm:left-6">
        <a
          href={toWhatsAppLink(settings.whatsapp, "مرحباً Source Meuble، أريد الاستفسار عن الأثاث حسب الطلب")}
          target="_blank"
          rel="noreferrer"
          aria-label="تواصل عبر واتساب"
          className="pulse-green flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-xl shadow-black/40 transition hover:scale-105"
        >
          <WhatsAppIcon className="h-7 w-7" />
        </a>
        <a
          href={toTelLink(settings.phone)}
          aria-label="اتصل بنا"
          className="flex h-11 w-11 items-center justify-center rounded-full border border-bronze-500/40 bg-ink-900/95 text-bronze-300 shadow-lg backdrop-blur transition hover:bg-bronze-500 hover:text-ink-950"
        >
          <svg viewBox="0 0 24 24" className="h-4.5 w-4.5" fill="none" stroke="currentColor" strokeWidth="1.8">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M3 5.5C3 4.4 4 3.5 5 3.5h2.2c.5 0 1 .3 1.1.8l.8 3c.1.4 0 .8-.3 1l-1.5 1.1a12.4 12.4 0 0 0 6.3 6.3l1.1-1.5c.2-.3.6-.4 1-.3l3 .8c.5.1.8.6.8 1.1V19c0 1.1-.9 2-2 2C10.6 21 3 13.4 3 6V5.5Z"
            />
          </svg>
        </a>
      </div>

      <button
        type="button"
        onClick={openAdmin}
        aria-label="لوحة تحكم الموقع"
        title="لوحة التحكم"
        className="fixed bottom-5 right-4 z-40 flex h-11 items-center gap-2 rounded-full border border-line-soft bg-ink-900/95 px-3.5 text-[11px] font-bold text-muted shadow-lg backdrop-blur transition hover:border-bronze-500 hover:text-bronze-300 sm:right-6"
      >
        <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="1.8">
          <rect x="4" y="10" width="16" height="10" rx="2" />
          <path d="M8 10V7a4 4 0 0 1 8 0v3" strokeLinecap="round" />
        </svg>
        إدارة الموقع
      </button>
    </>
  );
}
