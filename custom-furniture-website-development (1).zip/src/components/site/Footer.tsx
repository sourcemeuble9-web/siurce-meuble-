"use client";

import { useSite } from "@/lib/store";
import { toTelLink, toWhatsAppLink } from "@/lib/format";
import { Logo } from "./Logo";
import { WhatsAppIcon } from "./Navbar";

export function Footer() {
  const { data, openAdmin } = useSite();
  const { settings } = data;

  return (
    <footer className="border-t border-line bg-ink-950">
      <div className="shell grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <Logo />
          <p className="mt-4 max-w-xs text-xs leading-7 text-muted">
            {settings.companyName} — ورشة نجارة فاخرة. نصمم ونصنع المطابخ، غرف الدريسنج والمكاتب حسب المقاس، مع
            مخطط 2D وتصور 3D قبل التنفيذ.
          </p>
          <div className="mt-4 flex gap-2">
            {settings.instagram && (
              <a
                href={settings.instagram}
                target="_blank"
                rel="noreferrer"
                aria-label="Instagram"
                className="flex h-9 w-9 items-center justify-center rounded-full border border-line-soft text-muted transition hover:border-bronze-500 hover:text-bronze-300"
              >
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor">
                  <path d="M12 2.2c3.2 0 3.6 0 4.9.1 1.2.1 1.8.3 2.2.4.6.2 1 .5 1.4.9.4.4.7.8.9 1.4.2.4.4 1 .4 2.2.1 1.3.1 1.7.1 4.8s0 3.5-.1 4.8c-.1 1.2-.3 1.8-.4 2.2-.2.6-.5 1-.9 1.4-.4.4-.8.7-1.4.9-.4.2-1 .4-2.2.4-1.3.1-1.7.1-4.9.1s-3.6 0-4.9-.1c-1.2-.1-1.8-.3-2.2-.4-.6-.2-1-.5-1.4-.9-.4-.4-.7-.8-.9-1.4-.2-.4-.4-1-.4-2.2C2.2 15.5 2.2 15.1 2.2 12s0-3.5.1-4.8c.1-1.2.3-1.8.4-2.2.2-.6.5-1 .9-1.4.4-.4.8-.7 1.4-.9.4-.2 1-.4 2.2-.4C8.4 2.2 8.8 2.2 12 2.2Zm0 4.9a4.9 4.9 0 1 0 0 9.8 4.9 4.9 0 0 0 0-9.8Zm0 8.1a3.2 3.2 0 1 1 0-6.4 3.2 3.2 0 0 1 0 6.4Zm6.2-8.3a1.1 1.1 0 1 1-2.3 0 1.1 1.1 0 0 1 2.3 0Z" />
                </svg>
              </a>
            )}
            {settings.facebook && (
              <a
                href={settings.facebook}
                target="_blank"
                rel="noreferrer"
                aria-label="Facebook"
                className="flex h-9 w-9 items-center justify-center rounded-full border border-line-soft text-muted transition hover:border-bronze-500 hover:text-bronze-300"
              >
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor">
                  <path d="M13.5 21v-7h2.4l.4-2.8h-2.8V9.4c0-.8.2-1.4 1.4-1.4h1.5V5.5c-.3 0-1.2-.1-2.2-.1-2.2 0-3.7 1.3-3.7 3.8v2.1H8v2.8h2.5V21h3Z" />
                </svg>
              </a>
            )}
            <a
              href={settings.mapUrl}
              target="_blank"
              rel="noreferrer"
              aria-label="Google Maps"
              className="flex h-9 w-9 items-center justify-center rounded-full border border-line-soft text-muted transition hover:border-bronze-500 hover:text-bronze-300"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor">
                <path d="M12 2a7 7 0 0 0-7 7c0 5.2 7 13 7 13s7-7.8 7-13a7 7 0 0 0-7-7Zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5Z" />
              </svg>
            </a>
          </div>
        </div>

        <div>
          <h4 className="font-display text-xs tracking-[0.22em] text-bronze-400">EXPLORE</h4>
          <ul className="mt-4 space-y-2.5 text-xs font-semibold text-muted">
            {[
              { href: "#services", label: "خدماتنا" },
              { href: "#gallery", label: "معرض الأعمال" },
              { href: "#planning", label: "تصميم 2D و 3D" },
              { href: "#process", label: "مراحل العمل" },
              { href: "#about", label: "من نحن" },
              { href: "#contact", label: "تواصل معنا" },
            ].map((link) => (
              <li key={link.href}>
                <a href={link.href} className="transition hover:text-cream">
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-display text-xs tracking-[0.22em] text-bronze-400">SPECIALTIES</h4>
          <ul className="mt-4 space-y-2.5 text-xs font-semibold text-muted">
            {data.categories.map((category) => (
              <li key={category.id}>{category.name}</li>
            ))}
            <li>مخططات 2D و تصور 3D</li>
            <li>خدمة التركيب وضمان</li>
          </ul>
        </div>

        <div>
          <h4 className="font-display text-xs tracking-[0.22em] text-bronze-400">CONTACT</h4>
          <ul className="mt-4 space-y-3 text-xs font-semibold text-muted">
            <li>
              <a href={toTelLink(settings.phone)} className="flex items-center gap-2 transition hover:text-cream">
                <span className="text-bronze-400">📞</span>
                <span dir="ltr">{settings.phone}</span>
              </a>
            </li>
            <li>
              <a
                href={toWhatsAppLink(settings.whatsapp)}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 transition hover:text-cream"
              >
                <WhatsAppIcon className="h-3.5 w-3.5 text-[#25D366]" />
                واتساب
              </a>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-bronze-400">📍</span>
              <span>{settings.address}</span>
            </li>
            <li>
              <a
                href={settings.mapUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex rounded-full border border-bronze-500/40 px-3.5 py-1.5 text-[11px] font-bold text-bronze-300 transition hover:bg-bronze-500 hover:text-ink-950"
              >
                الاتجاهات على خرائط Google
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-line">
        <div className="shell flex flex-col items-center justify-between gap-3 py-5 sm:flex-row">
          <p className="text-[11px] text-muted">
            © {new Date().getFullYear()} {settings.companyName}. جميع الحقوق محفوظة.
          </p>
          <div className="flex items-center gap-4">
            <span className="text-[11px] text-muted">صُنع بشغف في الجزائر 🇩🇿</span>
            <button
              type="button"
              onClick={openAdmin}
              className="text-[11px] font-semibold text-muted/80 underline-offset-4 transition hover:text-bronze-300 hover:underline"
            >
              لوحة التحكم
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
