import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Cormorant_Garamond, Tajawal } from "next/font/google";
import { SiteDataProvider } from "@/lib/store";
import "./globals.css";

const tajawal = Tajawal({
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "700", "800"],
  variable: "--font-tajawal",
  display: "swap",
});

const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-cormorant",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Source Meuble | مطابخ، دريسينغ ومكاتب حسب الطلب",
  description:
    "Source Meuble — ورشة نجارة فاخرة في الجزائر. مطابخ عصرية، غرف دريسنج ومكاتب حسب الطلب مع مخططات 2D وتصور 3D قبل التنفيذ. الهاتف 0550808843.",
  keywords: [
    "Source Meuble",
    "مطابخ حسب الطلب",
    "دريسنج",
    "مكاتب",
    "نجارة",
    "تصميم 3D",
    "الجزائر",
  ],
  openGraph: {
    title: "Source Meuble | نجارة فاخرة حسب الطلب",
    description:
      "مطابخ، دريسينغ ومكاتب بتصاميم فاخرة — تصميم 2D و3D قبل التنفيذ. اتصل 0550808843.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className={`${tajawal.variable} ${cormorant.variable}`}>
      <body className="min-h-screen bg-ink-950 text-cream">
        <SiteDataProvider>{children}</SiteDataProvider>
      </body>
    </html>
  );
}
