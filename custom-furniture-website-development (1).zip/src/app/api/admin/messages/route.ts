import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { messages } from "@/db/schema";

export const dynamic = "force-dynamic";

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "SourceMeuble2024";

type Payload = {
  password?: string;
  action?: "list" | "delete" | "toggleRead";
  id?: number;
  read?: boolean;
};

async function listMessages() {
  return db.select().from(messages).orderBy(desc(messages.createdAt));
}

export async function POST(request: Request) {
  let payload: Payload | null = null;
  try {
    payload = (await request.json()) as Payload;
  } catch {
    return NextResponse.json({ error: "bad_request" }, { status: 400 });
  }

  if (!payload || payload.password !== ADMIN_PASSWORD) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }

  try {
    if (payload.action === "delete" && Number.isFinite(Number(payload.id))) {
      await db.delete(messages).where(eq(messages.id, Number(payload.id)));
    }

    if (payload.action === "toggleRead" && Number.isFinite(Number(payload.id))) {
      await db
        .update(messages)
        .set({ read: Boolean(payload.read) })
        .where(eq(messages.id, Number(payload.id)));
    }

    const rows = await listMessages();
    return NextResponse.json({ messages: rows });
  } catch {
    return NextResponse.json({ error: "server_error" }, { status: 500 });
  }
}
