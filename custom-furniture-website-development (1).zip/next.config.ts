import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Docker builds set BUILD_STANDALONE=1 so the output can run with `node server.js`
  // from a minimal image. The managed preview keeps the default output.
  ...(process.env.BUILD_STANDALONE === "1" ? { output: "standalone" as const } : {}),
  poweredByHeader: false,
};

export default nextConfig;
