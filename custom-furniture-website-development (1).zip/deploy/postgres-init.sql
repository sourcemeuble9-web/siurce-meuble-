-- يُنشّأ تلقائياً عند أول تشغيل لقاعدة البيانات في Docker
-- مطابق لمخطط Drizzle في src/db/schema.ts
CREATE TABLE IF NOT EXISTS categories (
  id serial PRIMARY KEY,
  name text NOT NULL,
  slug text NOT NULL UNIQUE,
  description text,
  image_url text,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS products (
  id serial PRIMARY KEY,
  category_id integer REFERENCES categories(id) ON DELETE SET NULL,
  name text NOT NULL,
  slug text NOT NULL UNIQUE,
  description text,
  image_url text,
  gallery jsonb NOT NULL DEFAULT '[]'::jsonb,
  price integer NOT NULL DEFAULT 0,
  is_starting_price boolean NOT NULL DEFAULT false,
  show_price_on_request boolean NOT NULL DEFAULT false,
  featured boolean NOT NULL DEFAULT false,
  available boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS site_settings (
  id serial PRIMARY KEY,
  company_name text NOT NULL DEFAULT 'Source Meuble',
  tagline text NOT NULL DEFAULT 'مطابخ عصرية - دريسينغ - مكاتب حسب الطلب',
  phone text NOT NULL DEFAULT '0550808843',
  whatsapp text NOT NULL DEFAULT '0550808843',
  map_url text NOT NULL DEFAULT 'https://maps.app.goo.gl/SmXT1y4o9eNJnhxs6',
  address text NOT NULL DEFAULT 'الجزائر',
  hero_title text NOT NULL DEFAULT 'Source Meuble',
  hero_subtitle text NOT NULL DEFAULT 'نصنع لكم مطابخ، دريسينغ ومكاتب على القياس بجودة عالية وتصاميم عصرية تناسب ذوقكم ومساحتكم',
  hero_image_url text NOT NULL DEFAULT '/images/hero.jpg',
  about_title text NOT NULL DEFAULT 'من نحن',
  about_text text NOT NULL DEFAULT 'Source Meuble ورشة جزائرية متخصصة في تصنيع وتركيب المطابخ والدريسينغ والمكاتب حسب الطلب.',
  about_image_url text NOT NULL DEFAULT '/images/about.jpg',
  facebook_url text,
  instagram_url text,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS messages (
  id serial PRIMARY KEY,
  name text NOT NULL,
  phone text NOT NULL,
  content text NOT NULL,
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS messages_created_at_idx ON messages (created_at DESC);
