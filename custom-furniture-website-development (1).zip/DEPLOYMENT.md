# دليل نشر موقع Source Meuble

هذا المشروع مبنى بـ **Next.js 16 (App Router)** + **PostgreSQL** + **Drizzle ORM**.
محتوى الموقع (منتجات، صور، أسعار، رقم الهاتف…) يُحفظ في **localStorage** داخل متصفحك (لوحة التحكم)، أما **رسائل العملاء** فتُحفظ في PostgreSQL.

---

## 1) ما تحتاجه قبل البدء

| العنصر | التفاصيل |
|---|---|
| حساب GitHub | لرفع الكود (مجاني) |
| استضافة | Vercel (أسهل، مجاني) أو سيرفر VPS مع Docker |
| قاعدة بيانات | Neon / Supabase (مجانية) أو PostgreSQL داخل VPS |
| نطاق (اختياري) | مثل `sourccemeuble.dz` أو `sourcceuble.com` |

> **مهم:** كلمة المرور مضبوطة حالياً في `.env.local` بالقيمة `wassim`.
> بدّلها إلى كلمة قوية قبل النشر، ويجب أن تكون `ADMIN_PASSWORD` و`NEXT_PUBLIC_ADMIN_PASSCODE` **نفس القيمة**.

---

## 2) الخيار الأسهل: Vercel + Neon (مجاناً، HTTPS ونطاق فرعي)

### أ. إنشاء قاعدة البيانات (Neon)
1. سجّل في <https://neon.tech> → **New Project** (اختر منطقة قريبة، مثل Frankfurt).
2. انسخ **Connection string** (يبدأ بـ `postgresql://...` وينتهي بـ `?sslmode=require`).
3. من جهازك، أنشئ الجداول (مرة واحدة فقط):

```bash
cd source-meuble
DATABASE_URL="postgresql://USER:PASSWORD@HOST/DB?sslmode=require" \
  npx drizzle-kit push --dialect postgresql --schema ./src/db/schema.ts \
  --url "postgresql://USER:PASSWORD@HOST/DB?sslmode=require"
```

### ب. رفع الكود إلى GitHub
```bash
git init
git add .
git commit -m "Source Meuble website"
git branch -M main
git remote add origin https://github.com/USERNAME/source-meuble.git
git push -u origin main
```
> ملفات `.env` و`.env.local` مستثناة تلقائياً من Git — لا تُرفع كلمات المرور.

### ج. النشر على Vercel
1. <https://vercel.com> → **Add New → Project** → اختر المستودع.
2. إعدادات البناء تُكتشف تلقائياً (Framework: Next.js).
3. في **Environment Variables** أضف:

| الاسم | القيمة |
|---|---|
| `DATABASE_URL` | رابط Neon مع `?sslmode=require` |
| `ADMIN_PASSWORD` | كلمة مرور قوية (مثال: `SM@2026!Atelier#7`) |
| `NEXT_PUBLIC_ADMIN_PASSCODE` | **نفس** كلمة المرور أعلاه |

4. اضغط **Deploy**. ستحصل على رابط مثل:
   `https://source-meuble.vercel.app`

> بعد أي تغيير في `NEXT_PUBLIC_*` يجب عمل **Redeploy** لأن القيمة تُدمج وقت البناء.

### د. ربط نطاقك الخاص
1. اشترِ النطاق (Namecheap / OVH / Google Domains…).
2. Vercel → Project → **Settings → Domains** → أضف `sourccemeuble.com` و`www.sourccemeuble.com`.
3. في لوحة النطاق أضف السجلات التي يعرضها Vercel، عادةً:
   - `A` للجذر → `76.76.21.21`
   - `CNAME` لـ `www` → `cname.vercel-dns.com`
4. انتظر انتشار DNS (5 دقائق – ساعتين)؛ شهادة SSL تُصدر تلقائياً.

---

## 3) الخيار الثاني: VPS خاص + Docker (تحكم كامل)

يناسب السيرفرات من Hetzner / Contabo / DigitalOcean (2GB RAM تكفي).

```bash
# على السيرفر (Ubuntu 22.04+)
sudo apt update && sudo apt install -y docker.io docker-compose-plugin git
git clone https://github.com/USERNAME/source-meuble.git
cd source-meuble

# أنشئ ملف الإعدادات
cat > .env <<'EOF'
POSTGRES_USER=sourcemeuble
POSTGRES_PASSWORD=كلمة_سر_قوية_لقاعدة_البيانات
POSTGRES_DB=source_meuble
ADMIN_PASSWORD=كلمة_مرور_قوية_للوحة
NEXT_PUBLIC_ADMIN_PASSCODE=كلمة_مرور_قوية_للوحة
APP_PORT=3000
EOF

# بناء وتشغيل (الموقع + قاعدة البيانات)
sudo docker compose up -d --build
```

افتح: `http://SERVER_IP:3000` — افحص الحالة عبر `/api/health`.

### إضافة HTTPS تلقائي (Caddy)
1. وجّه سجل DNS من نوع `A` للنطاق إلى عنوان IP السيرفر.
2. عدّل `deploy/Caddyfile` وضع نطاقك بدل `your-domain.com`.
3. شغّل:
```bash
sudo docker compose --profile proxy up -d
```
سيصدر Caddy شهادة SSL مجانية ويحوّل HTTP → HTTPS تلقائياً.

### أوامر مفيدة
```bash
sudo docker compose logs -f app      # سجلات الموقع
sudo docker compose restart app      # إعادة تشغيل
sudo docker compose down             # إيقاف
sudo docker compose up -d --build    # تحديث بعد تعديل الكود
```
نسخة احتياطية من الرسائل:
```bash
sudo docker compose exec db pg_dump -U sourcemeuble source_meuble > backup.sql
```

---

## 4) بعد النشر — قائمة تحقق

- [ ] افتح الموقع على الهاتف والكمبيوتر وتأكد من التصميم.
- [ ] اضغط زر واتساب وزر الاتصال: يجب أن يفتح `0550808843`.
- [ ] اضغط «خرائط Google»: يجب أن يفتح موقعك على الخريطة.
- [ ] أرسل رسالة من نموذج التواصل، ثم افتح **لوحة التحكم → الرسائل** وتأكد من وصولها.
- [ ] أدخل لوحة التحكم عبر ⚙️ أو `/admin` وبدّل صورة/سعراً وتحقق من ظهور التغيير.
- [ ] غيّر كلمة المرور من إعدادات الاستضافة إلى كلمة قوية.
- [ ] أضف الموقع إلى Google Search Console وأرسل `sitemap` (اختياري).

---

## 5) ملاحظات تقنية مهمة

1. **محتوى الموقع محلي:** المنتجات والأسعار والصور المرفوعة تُحفظ في متصفح الجهاز الذي عدّلت منه (localStorage). لتظهر نفس التعديلات على كل الأجهزة، استعمل **النسخ الاحتياطي → تصدير** ثم **استيراد** على الجهاز الآخر، أو اطلب ترقية تحفظ المنتجات في قاعدة البيانات (متاح كخطوة تطوير تالية).
2. **الصور المرفوعة من الجهاز** تُخزّن كـ Base64 داخل localStorage. للصور الثقيلة استعمل روابط صور (مثل `https://...jpg`) — أنت مضبوط على حد 1.4MB للصورة.
3. **أمان اللوحة:** `NEXT_PUBLIC_ADMIN_PASSCODE` يُدمج في حزمة المتصفح، لذا هو حماية ضد العبث العابر وليس حماية بنكية. رسائل العملاء وحذفها عبر `/api/admin/messages` محمي بـ `ADMIN_PASSWORD` على السيرفر. للحماية الكاملة (تسجيل دخول بمستخدمين) أخبرني لتنفيذها.
4. **قاعدة البيانات** تُستعمل فقط لجدول الرسائل حالياً. `/api/health` يتحقق من الاتصال ويعيد `{"ok":true}`.
5. **النطاق المؤقت الحالي** (`.e2b.app`) هو معاينة تطويرية وليس استضافة دائمة — للنشر الدائم استعمل أحد الخيارين أعلاه.

---

## 6) أوامر المشروع

```bash
npm install          # تثبيت الحزم
npm run dev          # تطوير محلي على http://localhost:3000
npm run build        # بناء للإنتاج
npm run start        # تشغيل نسخة الإنتاج
npx drizzle-kit push # مزامنة قاعدة البيانات مع المخطط
```
