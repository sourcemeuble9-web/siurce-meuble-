# Source Meuble — موقع الأثاث حسب الطلب

موقع تسويقي فاخر (Dark Luxury) لورشة نجارة تصنع **المطابخ العصرية، غرف الدريسنج والمكاتب** حسب القياس، مع خدمة تخطيط **2D و 3D** قبل التنفيذ.

- **الهاتف / واتساب:** 0550808843
- **الموقع:** https://maps.app.goo.gl/SmXT1y4o9eNJnhxs6
- **لوحة التحكم:** زر ⚙️ أعلى الموقع أو `/admin` — كلمة المرور من `NEXT_PUBLIC_ADMIN_PASSCODE`.

## التقنيات
Next.js 16 (App Router) · React 19 · Tailwind CSS 4 · PostgreSQL + Drizzle ORM

## تشغيل محلي
```bash
npm install
cp .env.example .env      # ثم عدّل DATABASE_URL وكلمات المرور
npx drizzle-kit push      # إنشاء الجداول
npm run dev               # http://localhost:3000
```

## النشر
راجع **[DEPLOYMENT.md](./DEPLOYMENT.md)** — يشمل Vercel + Neon، أو VPS عبر Docker Compose مع HTTPS تلقائي.

## المميزات
- واجهة عربية RTL كاملة ومتجاوبة، هوية داكنة بلمسات خشب وذهبي.
- معرض أعمال بفلاتر ونافذة تفاصيل وطلب عبر واتساب.
- قسم تفاعلي لمخطط 2D وتصور 3D.
- لوحة تحكم بلا خادم: إضافة/تعديل/حذف المنتجات، الفئات، الأسعار والصور، وتغيير الهاتف ورابط الخريطة (حفظ في localStorage + نسخ احتياطي JSON).
- نموذج تواصل يحفظ الرسائل في PostgreSQL، وإدارة الرسائل من اللوحة.
